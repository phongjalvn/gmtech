#SKD101|mekong|42|2011.09.23 01:04:49|294|3|51|1|4|1|11|1|1|3|2|57|1|7|1|30|26|48|2|3|2|1|38

DROP TABLE IF EXISTS `jos_banner`;
CREATE TABLE `jos_banner` (
  `bid` int(11) NOT NULL AUTO_INCREMENT,
  `cid` int(11) NOT NULL DEFAULT '0',
  `type` varchar(30) NOT NULL DEFAULT 'banner',
  `name` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `imptotal` int(11) NOT NULL DEFAULT '0',
  `impmade` int(11) NOT NULL DEFAULT '0',
  `clicks` int(11) NOT NULL DEFAULT '0',
  `imageurl` varchar(100) NOT NULL DEFAULT '',
  `clickurl` varchar(200) NOT NULL DEFAULT '',
  `date` datetime DEFAULT NULL,
  `showBanner` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `editor` varchar(50) DEFAULT NULL,
  `custombannercode` text,
  `catid` int(10) unsigned NOT NULL DEFAULT '0',
  `description` text NOT NULL,
  `sticky` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `tags` text NOT NULL,
  `params` text NOT NULL,
  PRIMARY KEY (`bid`),
  KEY `viewbanner` (`showBanner`),
  KEY `idx_banner_catid` (`catid`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `jos_bannerclient`;
CREATE TABLE `jos_bannerclient` (
  `cid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `contact` varchar(255) NOT NULL DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `extrainfo` text NOT NULL,
  `checked_out` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out_time` time DEFAULT NULL,
  `editor` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`cid`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `jos_bannertrack`;
CREATE TABLE `jos_bannertrack` (
  `track_date` date NOT NULL,
  `track_type` int(10) unsigned NOT NULL,
  `banner_id` int(10) unsigned NOT NULL
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `jos_categories`;
CREATE TABLE `jos_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `name` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `image` varchar(255) NOT NULL DEFAULT '',
  `section` varchar(50) NOT NULL DEFAULT '',
  `image_position` varchar(30) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out` int(11) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `editor` varchar(50) DEFAULT NULL,
  `ordering` int(11) NOT NULL DEFAULT '0',
  `access` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `count` int(11) NOT NULL DEFAULT '0',
  `params` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `cat_idx` (`section`,`published`,`access`),
  KEY `idx_access` (`access`),
  KEY `idx_checkout` (`checked_out`)
) ENGINE=MyISAM AUTO_INCREMENT=4 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `jos_categories` VALUES
(1, 0, 'Tin tức', '', 'tin-tc', '', '1', 'left', '', 1, 0, '0000-00-00 00:00:00', NULL, 1, 0, 0, ''),
(2, 0, 'sanpham', '', 'sanpham', '', '1', 'left', '', 1, 0, '0000-00-00 00:00:00', NULL, 2, 0, 0, ''),
(3, 0, 'lienhe', '', 'lienhe', '', 'com_contact_details', 'left', '', 1, 0, '0000-00-00 00:00:00', NULL, 1, 0, 0, '');

DROP TABLE IF EXISTS `jos_components`;
CREATE TABLE `jos_components` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL DEFAULT '',
  `link` varchar(255) NOT NULL DEFAULT '',
  `menuid` int(11) unsigned NOT NULL DEFAULT '0',
  `parent` int(11) unsigned NOT NULL DEFAULT '0',
  `admin_menu_link` varchar(255) NOT NULL DEFAULT '',
  `admin_menu_alt` varchar(255) NOT NULL DEFAULT '',
  `option` varchar(50) NOT NULL DEFAULT '',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `admin_menu_img` varchar(255) NOT NULL DEFAULT '',
  `iscore` tinyint(4) NOT NULL DEFAULT '0',
  `params` text NOT NULL,
  `enabled` tinyint(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `parent_option` (`parent`,`option`(32))
) ENGINE=MyISAM AUTO_INCREMENT=60 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `jos_components` VALUES
(1, 'Banners', '', 0, 0, '', 'Banner Management', 'com_banners', 0, 'js/ThemeOffice/component.png', 0, 'track_impressions=0\ntrack_clicks=0\ntag_prefix=\n\n', 1),
(2, 'Banners', '', 0, 1, 'option=com_banners', 'Active Banners', 'com_banners', 1, 'js/ThemeOffice/edit.png', 0, '', 1),
(3, 'Clients', '', 0, 1, 'option=com_banners&c=client', 'Manage Clients', 'com_banners', 2, 'js/ThemeOffice/categories.png', 0, '', 1),
(4, 'Web Links', 'option=com_weblinks', 0, 0, '', 'Manage Weblinks', 'com_weblinks', 0, 'js/ThemeOffice/component.png', 0, 'show_comp_description=1\ncomp_description=\nshow_link_hits=1\nshow_link_description=1\nshow_other_cats=1\nshow_headings=1\nshow_page_title=1\nlink_target=0\nlink_icons=\n\n', 1),
(5, 'Links', '', 0, 4, 'option=com_weblinks', 'View existing weblinks', 'com_weblinks', 1, 'js/ThemeOffice/edit.png', 0, '', 1),
(6, 'Categories', '', 0, 4, 'option=com_categories&section=com_weblinks', 'Manage weblink categories', '', 2, 'js/ThemeOffice/categories.png', 0, '', 1),
(7, 'Contacts', 'option=com_contact', 0, 0, '', 'Edit contact details', 'com_contact', 0, 'js/ThemeOffice/component.png', 1, 'contact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_fax=\nicon_misc=\nshow_headings=1\nshow_position=1\nshow_email=0\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nbannedEmail=\nbannedSubject=\nbannedText=\nsession=1\ncustomReply=0\n\n', 1),
(8, 'Contacts', '', 0, 7, 'option=com_contact', 'Edit contact details', 'com_contact', 0, 'js/ThemeOffice/edit.png', 1, '', 1),
(9, 'Categories', '', 0, 7, 'option=com_categories&section=com_contact_details', 'Manage contact categories', '', 2, 'js/ThemeOffice/categories.png', 1, 'contact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_fax=\nicon_misc=\nshow_headings=1\nshow_position=1\nshow_email=0\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nbannedEmail=\nbannedSubject=\nbannedText=\nsession=1\ncustomReply=0\n\n', 1),
(10, 'Polls', 'option=com_poll', 0, 0, 'option=com_poll', 'Manage Polls', 'com_poll', 0, 'js/ThemeOffice/component.png', 0, '', 1),
(11, 'News Feeds', 'option=com_newsfeeds', 0, 0, '', 'News Feeds Management', 'com_newsfeeds', 0, 'js/ThemeOffice/component.png', 0, '', 1),
(12, 'Feeds', '', 0, 11, 'option=com_newsfeeds', 'Manage News Feeds', 'com_newsfeeds', 1, 'js/ThemeOffice/edit.png', 0, 'show_headings=1\nshow_name=1\nshow_articles=1\nshow_link=1\nshow_cat_description=1\nshow_cat_items=1\nshow_feed_image=1\nshow_feed_description=1\nshow_item_description=1\nfeed_word_count=0\n\n', 1),
(13, 'Categories', '', 0, 11, 'option=com_categories&section=com_newsfeeds', 'Manage Categories', '', 2, 'js/ThemeOffice/categories.png', 0, '', 1),
(14, 'User', 'option=com_user', 0, 0, '', '', 'com_user', 0, '', 1, '', 1),
(15, 'Search', 'option=com_search', 0, 0, 'option=com_search', 'Search Statistics', 'com_search', 0, 'js/ThemeOffice/component.png', 1, 'enabled=0\n\n', 1),
(16, 'Categories', '', 0, 1, 'option=com_categories&section=com_banner', 'Categories', '', 3, '', 1, '', 1),
(17, 'Wrapper', 'option=com_wrapper', 0, 0, '', 'Wrapper', 'com_wrapper', 0, '', 1, '', 1),
(18, 'Mail To', '', 0, 0, '', '', 'com_mailto', 0, '', 1, '', 1),
(19, 'Media Manager', '', 0, 0, 'option=com_media', 'Media Manager', 'com_media', 0, '', 1, 'upload_extensions=bmp,csv,doc,epg,gif,ico,jpg,odg,odp,ods,odt,pdf,png,ppt,swf,txt,xcf,xls,BMP,CSV,DOC,EPG,GIF,ICO,JPG,ODG,ODP,ODS,ODT,PDF,PNG,PPT,SWF,TXT,XCF,XLS\nupload_maxsize=10000000\nfile_path=images\nimage_path=images/stories\nrestrict_uploads=1\nallowed_media_usergroup=3\ncheck_mime=1\nimage_extensions=bmp,gif,jpg,png\nignore_extensions=\nupload_mime=image/jpeg,image/gif,image/png,image/bmp,application/x-shockwave-flash,application/msword,application/excel,application/pdf,application/powerpoint,text/plain,application/x-zip\nupload_mime_illegal=text/html\nenable_flash=0\n\n', 1),
(20, 'Articles', 'option=com_content', 0, 0, '', '', 'com_content', 0, '', 1, 'show_noauth=0\nshow_title=1\nlink_titles=0\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_author=0\nshow_create_date=0\nshow_modify_date=0\nshow_item_navigation=0\nshow_readmore=1\nshow_vote=0\nshow_icons=0\nshow_pdf_icon=0\nshow_print_icon=0\nshow_email_icon=0\nshow_hits=0\nfeed_summary=0\nfilter_tags=\nfilter_attritbutes=\n\n', 1),
(21, 'Configuration Manager', '', 0, 0, '', 'Configuration', 'com_config', 0, '', 1, '', 1),
(22, 'Installation Manager', '', 0, 0, '', 'Installer', 'com_installer', 0, '', 1, '', 1),
(23, 'Language Manager', '', 0, 0, '', 'Languages', 'com_languages', 0, '', 1, 'site=en-GB\n\n', 1),
(24, 'Mass mail', '', 0, 0, '', 'Mass Mail', 'com_massmail', 0, '', 1, 'mailSubjectPrefix=\nmailBodySuffix=\n\n', 1),
(25, 'Menu Editor', '', 0, 0, '', 'Menu Editor', 'com_menus', 0, '', 1, '', 1),
(27, 'Messaging', '', 0, 0, '', 'Messages', 'com_messages', 0, '', 1, '', 1),
(28, 'Modules Manager', '', 0, 0, '', 'Modules', 'com_modules', 0, '', 1, '', 1),
(29, 'Plugin Manager', '', 0, 0, '', 'Plugins', 'com_plugins', 0, '', 1, '', 1),
(30, 'Template Manager', '', 0, 0, '', 'Templates', 'com_templates', 0, '', 1, '', 1),
(31, 'User Manager', '', 0, 0, '', 'Users', 'com_users', 0, '', 1, 'allowUserRegistration=1\nnew_usertype=Registered\nuseractivation=1\nfrontend_userparams=1\n\n', 1),
(32, 'Cache Manager', '', 0, 0, '', 'Cache', 'com_cache', 0, '', 1, '', 1),
(33, 'Control Panel', '', 0, 0, '', 'Control Panel', 'com_cpanel', 0, '', 1, '', 1),
(34, 'JCE', 'option=com_jce', 0, 0, 'option=com_jce', 'JCE', 'com_jce', 0, 'components/com_jce/img/logo.png', 0, '', 1),
(35, 'JCE MENU CPANEL', '', 0, 34, 'option=com_jce', 'JCE MENU CPANEL', 'com_jce', 0, 'templates/khepri/images/menu/icon-16-cpanel.png', 0, '', 1),
(36, 'JCE MENU CONFIG', '', 0, 34, 'option=com_jce&type=config', 'JCE MENU CONFIG', 'com_jce', 1, 'templates/khepri/images/menu/icon-16-config.png', 0, '', 1),
(37, 'JCE MENU GROUPS', '', 0, 34, 'option=com_jce&type=group', 'JCE MENU GROUPS', 'com_jce', 2, 'templates/khepri/images/menu/icon-16-user.png', 0, '', 1),
(38, 'JCE MENU PLUGINS', '', 0, 34, 'option=com_jce&type=plugin', 'JCE MENU PLUGINS', 'com_jce', 3, 'templates/khepri/images/menu/icon-16-plugin.png', 0, '', 1),
(39, 'JCE MENU INSTALL', '', 0, 34, 'option=com_jce&type=install', 'JCE MENU INSTALL', 'com_jce', 4, 'templates/khepri/images/menu/icon-16-install.png', 0, '', 1),
(48, 'Joom!Fish', 'option=com_joomfish', 0, 0, 'option=com_joomfish', 'Joom!Fish', 'com_joomfish', 0, 'components/com_joomfish/assets/images/icon-16-joomfish.png', 0, 'noTranslation=2\ndefaultText=\noverwriteGlobalConfig=0\ndirectory_flags=components/com_joomfish/images\nstorageOfOriginal=md5\nfrontEndPublish=1\nfrontEndPreview=1\nshowDefaultLanguageAdmin=0\ncopyparams=1\ntranscaching=0\ncachelife=180\nqacaching=1\nqalogging=0', 1),
(49, 'Control Panel', '', 0, 48, 'option=com_joomfish', 'Control Panel', 'com_joomfish', 0, 'components/com_joomfish/assets/images/icon-16-cpanel.png', 0, '', 1),
(50, 'Translation', '', 0, 48, 'option=com_joomfish&task=translate.overview', 'Translation', 'com_joomfish', 1, 'components/com_joomfish/assets/images/icon-16-translation.png', 0, '', 1),
(51, 'Orphan Translations', '', 0, 48, 'option=com_joomfish&task=translate.orphans', 'Orphan Translations', 'com_joomfish', 2, 'components/com_joomfish/assets/images/icon-16-orphan.png', 0, '', 1),
(52, 'Manage Translations', '', 0, 48, 'option=com_joomfish&task=manage.overview', 'Manage Translations', 'com_joomfish', 3, 'components/com_joomfish/assets/images/icon-16-manage.png', 0, '', 1),
(53, 'Statistics', '', 0, 48, 'option=com_joomfish&task=statistics.overview', 'Statistics', 'com_joomfish', 4, 'components/com_joomfish/assets/images/icon-16-statistics.png', 0, '', 1),
(47, 'Vinaora Visitors Counter', 'option=com_vvisit_counter', 0, 0, 'option=com_vvisit_counter', 'Vinaora Visitors Counter', 'com_vvisit_counter', 0, 'js/ThemeOffice/component.png', 0, '', 1),
(54, '', '', 0, 48, 'option=com_joomfish', '', 'com_joomfish', 5, 'components/com_joomfish/assets/images/icon-10-blank.png', 0, '', 1),
(55, 'Languages', '', 0, 48, 'option=com_joomfish&task=languages.show', 'Languages', 'com_joomfish', 6, 'components/com_joomfish/assets/images/icon-16-language.png', 0, '', 1),
(56, 'Content elements', '', 0, 48, 'option=com_joomfish&task=elements.show', 'Content elements', 'com_joomfish', 7, 'components/com_joomfish/assets/images/icon-16-extension.png', 0, '', 1),
(57, 'Plugins', '', 0, 48, 'option=com_joomfish&task=plugin.show', 'Plugins', 'com_joomfish', 8, 'components/com_joomfish/assets/images/icon-16-plugin.png', 0, '', 1),
(58, '', '', 0, 48, 'option=com_joomfish', '', 'com_joomfish', 9, 'components/com_joomfish/assets/images/icon-10-blank.png', 0, '', 1),
(59, 'Help', '', 0, 48, 'option=com_joomfish&task=help.show', 'Help', 'com_joomfish', 10, 'components/com_joomfish/assets/images/icon-16-help.png', 0, '', 1);

DROP TABLE IF EXISTS `jos_contact_details`;
CREATE TABLE `jos_contact_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `con_position` varchar(255) DEFAULT NULL,
  `address` text,
  `suburb` varchar(100) DEFAULT NULL,
  `state` varchar(100) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `postcode` varchar(100) DEFAULT NULL,
  `telephone` varchar(255) DEFAULT NULL,
  `fax` varchar(255) DEFAULT NULL,
  `misc` mediumtext,
  `image` varchar(255) DEFAULT NULL,
  `imagepos` varchar(20) DEFAULT NULL,
  `email_to` varchar(255) DEFAULT NULL,
  `default_con` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `published` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `checked_out` int(11) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `params` text NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `catid` int(11) NOT NULL DEFAULT '0',
  `access` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `mobile` varchar(255) NOT NULL DEFAULT '',
  `webpage` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `jos_contact_details` VALUES
(1, 'Contact', 'contact', '', '', '', '', '', '', '', '', '', '', NULL, 'htkieuphuong@gmail.com', 0, 1, 0, '0000-00-00 00:00:00', 1, 'show_name=1\nshow_position=0\nshow_email=0\nshow_street_address=0\nshow_suburb=0\nshow_state=0\nshow_postcode=0\nshow_country=0\nshow_telephone=0\nshow_mobile=0\nshow_fax=0\nshow_webpage=0\nshow_misc=0\nshow_image=0\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 3, 0, '', '');

DROP TABLE IF EXISTS `jos_content`;
CREATE TABLE `jos_content` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `title_alias` varchar(255) NOT NULL DEFAULT '',
  `introtext` mediumtext NOT NULL,
  `fulltext` mediumtext NOT NULL,
  `state` tinyint(3) NOT NULL DEFAULT '0',
  `sectionid` int(11) unsigned NOT NULL DEFAULT '0',
  `mask` int(11) unsigned NOT NULL DEFAULT '0',
  `catid` int(11) unsigned NOT NULL DEFAULT '0',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(11) unsigned NOT NULL DEFAULT '0',
  `created_by_alias` varchar(255) NOT NULL DEFAULT '',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(11) unsigned NOT NULL DEFAULT '0',
  `checked_out` int(11) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `images` text NOT NULL,
  `urls` text NOT NULL,
  `attribs` text NOT NULL,
  `version` int(11) unsigned NOT NULL DEFAULT '1',
  `parentid` int(11) unsigned NOT NULL DEFAULT '0',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `metakey` text NOT NULL,
  `metadesc` text NOT NULL,
  `access` int(11) unsigned NOT NULL DEFAULT '0',
  `hits` int(11) unsigned NOT NULL DEFAULT '0',
  `metadata` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_section` (`sectionid`),
  KEY `idx_access` (`access`),
  KEY `idx_checkout` (`checked_out`),
  KEY `idx_state` (`state`),
  KEY `idx_catid` (`catid`),
  KEY `idx_createdby` (`created_by`)
) ENGINE=MyISAM AUTO_INCREMENT=5 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `jos_content` VALUES
(1, 'Product test1', 'product-test1', '', '<span>Commercial Products</span> \r\n<hr />\r\n<span>Products</span><br />\r\n<p> </p>\r\n<p>We offer a wide range of wheat flour catering for every requirement. The products are categorized as follows:</p>\r\n<h2>Commercial Products by Protein Level</h2>\r\n<table id=\"table-frame\" width=\"100%\" border=\"0\" cellpadding=\"5\" cellspacing=\"0\">\r\n<tbody>\r\n<tr>\r\n<td width=\"25%\" align=\"center\" bgcolor=\"#fade91\"><strong>High Protein</strong></td>\r\n<td width=\"25%\" align=\"center\" bgcolor=\"#fade91\"><strong>Medium Protein</strong></td>\r\n<td width=\"25%\" align=\"center\" bgcolor=\"#fade91\"><strong>Low Protein</strong></td>\r\n<td width=\"25%\" align=\"center\" bgcolor=\"#fade91\"><strong>Specialty</strong></td>\r\n</tr>\r\n<tr>\r\n<td width=\"25%\" align=\"center\" bgcolor=\"#fcf4d2\">\r\n<p><a><img src=\"http://mfm.com.my.tmp4.mschosting.com/userfiles/image/products-logo/gs_09.gif\" width=\"20\" border=\"0\" height=\"33\" /></a></p>\r\n<p><a href=\"index.php?option=com_content&amp;view=article&amp;id=4:abc&amp;catid=2\" onclick=\"window.open(this.href,\'MalayanFlourMillsGoldenStatue\',\'resizable=no,location=no,menubar=no,scrollbars=yes,status=no,toolbar=no,fullscreen=no,dependent=no,width=500,height=500,left=200,top=100,status\'); return false\">Golden Statue</a></p>\r\n</td>\r\n<td width=\"25%\" align=\"center\" bgcolor=\"#fcf4d2\">\r\n<p><a onclick=\"window.open(this.href,\'MalayanFlourMillsRotiCanaiFlour\',\'resizable=no,location=no,menubar=no,scrollbars=yes,status=no,toolbar=no,fullscreen=no,dependent=no,width=500,height=500,left=200,top=100,status\'); return false\" href=\"index.php?p=contents-item&amp;id=214\"><img src=\"http://mfm.com.my.tmp4.mschosting.com/userfiles/image/products-logo/roti-canai_09.gif\" width=\"25\" border=\"0\" height=\"33\" /></a></p>\r\n<p>Roti Canai Flour</p>\r\n</td>\r\n<td width=\"25%\" align=\"center\" bgcolor=\"#fcf4d2\">\r\n<p><a onclick=\"window.open(this.href,\'MalayanFlourMillsYellowRoses\',\'resizable=no,location=no,menubar=no,scrollbars=yes,status=no,toolbar=no,fullscreen=no,dependent=no,width=500,height=500,left=200,top=100,status\'); return false\" href=\"index.php?p=contents-item&amp;id=219\"><img src=\"http://mfm.com.my.tmp4.mschosting.com/userfiles/image/products-logo/yellowrose_09.gif\" width=\"34\" border=\"0\" height=\"25\" /></a></p>\r\n<p>Yellow Roses</p>\r\n</td>\r\n<td width=\"25%\" align=\"center\" bgcolor=\"#fcf4d2\">\r\n<p><a href=\"index.php?p=contents-item&amp;id=243\" onclick=\"window.open(this.href,\'MalayanFlourMillsWholemeal\',\'resizable=no,location=no,menubar=no,scrollbars=yes,status=no,toolbar=no,fullscreen=no,dependent=no,width=500,height=500,left=200,top=100,status\'); return false\"><img src=\"http://mfm.com.my.tmp4.mschosting.com/userfiles/image/products-logo/wholemeal09.gif\" width=\"25\" border=\"0\" height=\"33\" /></a></p>\r\n<p>Wholemeal</p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td width=\"25%\" align=\"center\" bgcolor=\"#f8e9bf\">\r\n<p><a href=\"index.php?p=contents-item&amp;id=210\" onclick=\"window.open(this.href,\'MalayanFlourMillsSPN\',\'resizable=no,location=no,menubar=no,scrollbars=yes,status=no,toolbar=no,fullscreen=no,dependent=no,width=500,height=500,left=200,top=100,status\'); return false\"><img src=\"http://mfm.com.my.tmp4.mschosting.com/userfiles/image/products-logo/spn_09.gif\" width=\"25\" border=\"0\" height=\"33\" /></a></p>\r\n<p>SPN</p>\r\n</td>\r\n<td width=\"25%\" align=\"center\" bgcolor=\"#f8e9bf\">\r\n<p><a href=\"index.php?p=contents-item&amp;id=215\" onclick=\"window.open(this.href,\'MalayanFlourMillsRedRoses\',\'resizable=no,location=no,menubar=no,scrollbars=yes,status=no,toolbar=no,fullscreen=no,dependent=no,width=500,height=500,left=200,top=100,status\'); return false\"><img src=\"http://mfm.com.my.tmp4.mschosting.com/userfiles/image/products-logo/roses_09.gif\" width=\"34\" border=\"0\" height=\"25\" /></a></p>\r\n<p>Red Roses</p>\r\n</td>\r\n<td width=\"25%\" align=\"center\" bgcolor=\"#f8e9bf\">\r\n<p><a href=\"index.php?p=contents-item&amp;id=220\" onclick=\"window.open(this.href,\'MalayanFlourMillsSPIII\',\'resizable=no,location=no,menubar=no,scrollbars=yes,status=no,toolbar=no,fullscreen=no,dependent=no,width=500,height=500,left=200,top=100,status\'); return false\"><img src=\"http://mfm.com.my.tmp4.mschosting.com/userfiles/image/products-logo/sp3_09.gif\" width=\"25\" border=\"0\" height=\"33\" /></a></p>\r\n<p>SP III</p>\r\n</td>\r\n<td width=\"25%\" align=\"center\" bgcolor=\"#f8e9bf\">\r\n<p><a href=\"index.php?p=contents-item&amp;id=244\" onclick=\"window.open(this.href,\'MalayanFlourMillsSpecialWholemeal\',\'resizable=no,location=no,menubar=no,scrollbars=yes,status=no,toolbar=no,fullscreen=no,dependent=no,width=500,height=500,left=200,top=100,status\'); return false\"><img src=\"http://mfm.com.my.tmp4.mschosting.com/userfiles/image/products-logo/speacial_wholemeal09.gif\" width=\"30\" border=\"0\" height=\"33\" /></a></p>\r\n<p>Special Wholemeal</p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td width=\"25%\" align=\"center\" bgcolor=\"#fcf4d2\">\r\n<p><a href=\"index.php?p=contents-item&amp;id=211\" onclick=\"window.open(this.href,\'MalayanFlourMillsDiamond\',\'resizable=no,location=no,menubar=no,scrollbars=yes,status=no,toolbar=no,fullscreen=no,dependent=no,width=500,height=500,left=200,top=100,status\'); return false\"><img src=\"http://mfm.com.my.tmp4.mschosting.com/userfiles/image/products-logo/diamond_light_09.gif\" width=\"34\" border=\"0\" height=\"25\" /></a></p>\r\n<p>Diamond</p>\r\n</td>\r\n<td width=\"25%\" align=\"center\" bgcolor=\"#fcf4d2\">\r\n<p><a href=\"index.php?p=contents-item&amp;id=216\" onclick=\"window.open(this.href,\'MalayanFlourMillsRedBicycle\',\'resizable=no,location=no,menubar=no,scrollbars=yes,status=no,toolbar=no,fullscreen=no,dependent=no,width=500,height=500,left=200,top=100,status\'); return false\"><img src=\"http://mfm.com.my.tmp4.mschosting.com/userfiles/image/products-logo/bicycle_light_09.gif\" width=\"34\" border=\"0\" height=\"25\" /></a></p>\r\n<p>Red Bicycle</p>\r\n</td>\r\n<td width=\"25%\" align=\"center\" bgcolor=\"#fcf4d2\">&nbsp;</td>\r\n<td width=\"25%\" align=\"center\" bgcolor=\"#fcf4d2\">\r\n<p><a href=\"index.php?p=contents-item&amp;id=245\" onclick=\"window.open(this.href,\'MalayanflourMillsBlueFlyingWheel\',\'resizable=no,location=no,menubar=no,scrollbars=yes,status=no,toolbar=no,fullscreen=no,dependent=no,width=500,height=500,left=200,top=100,status\'); return false\"><img src=\"http://mfm.com.my.tmp4.mschosting.com/userfiles/image/products-logo/blue_semolina_light09.gif\" width=\"34\" border=\"0\" height=\"25\" /></a></p>\r\n<p>Blue Flying Wheel (Semolina)</p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td width=\"25%\" align=\"center\" bgcolor=\"#f8e9bf\">\r\n<p><a href=\"index.php?p=contents-item&amp;id=212\" onclick=\"window.open(this.href,\'MalayanFlourMillsBalance\',\'resizable=no,location=no,menubar=no,scrollbars=yes,status=no,toolbar=no,fullscreen=no,dependent=no,width=500,height=500,left=200,top=100,status\'); return false\"><img src=\"http://mfm.com.my.tmp4.mschosting.com/userfiles/image/products-logo/balance_dark_09.gif\" width=\"34\" border=\"0\" height=\"25\" /></a></p>\r\n<p>Balance</p>\r\n</td>\r\n<td width=\"25%\" align=\"center\" bgcolor=\"#f8e9bf\">\r\n<p><a href=\"index.php?p=contents-item&amp;id=217\" onclick=\"window.open(this.href,\'MalayanFlourMillsBlueRoses\',\'resizable=no,location=no,menubar=no,scrollbars=yes,status=no,toolbar=no,fullscreen=no,dependent=no,width=500,height=500,left=200,top=100,status\'); return false\"><img src=\"http://mfm.com.my.tmp4.mschosting.com/userfiles/image/products-logo/bluerosses_dark_09.gif\" width=\"34\" border=\"0\" height=\"25\" /></a></p>\r\n<p>Blue Roses</p>\r\n</td>\r\n<td width=\"25%\" align=\"center\" bgcolor=\"#f8e9bf\">&nbsp;</td>\r\n<td width=\"25%\" align=\"center\" bgcolor=\"#f8e9bf\">\r\n<p><a onclick=\"window.open(this.href,\'MalayanFlourMillsRedFlyingWheel\',\'resizable=no,location=no,menubar=no,scrollbars=yes,status=no,toolbar=no,fullscreen=no,dependent=no,width=500,height=500,left=200,top=100,status\'); return false\" href=\"index.php?p=contents-item&amp;id=246\"><img src=\"http://mfm.com.my.tmp4.mschosting.com/userfiles/image/products-logo/rw_attar_light09.gif\" width=\"34\" border=\"0\" height=\"25\" /></a></p>\r\n<p>Red Flying Wheel (Atta flour)</p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td align=\"center\" bgcolor=\"#fcf4d2\">\r\n<p><a onclick=\"window.open(this.href,\'MalayanFlourMillsLoveBird\',\'resizable=no,location=no,menubar=no,scrollbars=yes,status=no,toolbar=no,fullscreen=no,dependent=no,width=500,height=500,left=200,top=100,status\'); return false\" href=\"index.php?p=contents-item&amp;id=213\"><img src=\"http://mfm.com.my.tmp4.mschosting.com/userfiles/image/products-logo/lovebirds_09.gif\" width=\"34\" border=\"0\" height=\"25\" /></a></p>\r\n<p>Love Birds</p>\r\n</td>\r\n<td align=\"center\" bgcolor=\"#fcf4d2\">\r\n<p><a href=\"index.php?p=contents-item&amp;id=218\" onclick=\"window.open(this.href,\'MalayanFlourMillsBlueBicycle\',\'resizable=no,location=no,menubar=no,scrollbars=yes,status=no,toolbar=no,fullscreen=no,dependent=no,width=500,height=500,left=200,top=100,status\'); return false\"><img src=\"http://mfm.com.my.tmp4.mschosting.com/userfiles/image/products-logo/bluebicycle_light_09.gif\" width=\"34\" border=\"0\" height=\"25\" /></a></p>\r\n<a href=\"index.php?p=contents-item&amp;id=218\" onclick=\"window.open(this.href,\'MalayanFlourMillsBlueBicycle\',\'resizable=no,location=no,menubar=no,scrollbars=yes,status=no,toolbar=no,fullscreen=no,dependent=no,width=500,height=500,left=200,top=100,status\'); return false\"> </a>Blue Bicycle</td>\r\n<td align=\"center\" bgcolor=\"#fcf4d2\">&nbsp;</td>\r\n<td align=\"center\" bgcolor=\"#fcf4d2\">\r\n<p><a href=\"index.php?p=contents-item&amp;id=270\" onclick=\"window.open(this.href,\'MalayanFlourMillsDHRWFchlorinated\',\'resizable=no,location=no,menubar=no,scrollbars=yes,status=no,toolbar=no,fullscreen=no,dependent=no,width=500,height=500,left=200,top=100,status\'); return false\"><img src=\"http://mfm.com.my.tmp4.mschosting.com/userfiles/image/products-logo/dove_chlorinate.gif\" width=\"33\" border=\"0\" height=\"25\" /></a></p>\r\n<p>Dove High Ratio Wheat Flour (Chlorinated) <br /> *Available end February 2009</p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td align=\"center\" bgcolor=\"#f8e9bf\">&nbsp;</td>\r\n<td align=\"center\" bgcolor=\"#f8e9bf\">&nbsp;</td>\r\n<td align=\"center\" bgcolor=\"#f8e9bf\">&nbsp;</td>\r\n<td align=\"center\" bgcolor=\"#f8e9bf\">\r\n<p><a onclick=\"window.open(this.href,\'MalayanFlourMIllsDHRWF\',\'resizable=no,location=no,menubar=no,scrollbars=yes,status=no,toolbar=no,fullscreen=no,dependent=no,width=500,height=500,left=200,top=100,status\'); return false\" href=\"index.php?p=contents-item&amp;id=271\"><img src=\"http://mfm.com.my.tmp4.mschosting.com/userfiles/image/products-logo/dove_blue.gif\" width=\"33\" border=\"0\" height=\"25\" /></a></p>\r\n<p>Dove High Ratio Wheat Flour<br /> *Available end February 2009</p>\r\n</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<p> </p>\r\n<h2>Commercial Products by Usage</h2>\r\n<table id=\"table-frame\" width=\"100%\" border=\"0\" cellpadding=\"5\" cellspacing=\"0\">\r\n<tbody>\r\n<tr>\r\n<td style=\"text-align: center;\" width=\"20%\" bgcolor=\"#fade91\"><strong>&nbsp;Breads / Buns</strong></td>\r\n<td style=\"text-align: center;\" width=\"20%\" bgcolor=\"#fade91\"><strong>Wantan Noodles</strong></td>\r\n<td style=\"text-align: center;\" width=\"20%\" bgcolor=\"#fade91\"><strong>Other Noodles, Vermicelli, \"Mee Suah\"</strong></td>\r\n<td style=\"text-align: center;\" width=\"20%\" bgcolor=\"#fade91\"><strong>Cakes, Pastries, Biscuits, Cookies and Snacks</strong></td>\r\n<td style=\"text-align: center;\" width=\"20%\" bgcolor=\"#fade91\"><strong>Roti Canai </strong></td>\r\n</tr>\r\n<tr>\r\n<td style=\"text-align: center;\" width=\"20%\" bgcolor=\"#fade91\"><img src=\"http://mfm.com.my.tmp4.mschosting.com/userfiles/image/products/commercial%20products/bread.gif\" width=\"120\" height=\"120\" /></td>\r\n<td style=\"text-align: center;\" width=\"20%\" bgcolor=\"#fade91\"><img src=\"http://mfm.com.my.tmp4.mschosting.com/userfiles/image/products/commercial%20products/wantann.gif\" width=\"120\" height=\"120\" /></td>\r\n<td style=\"text-align: center;\" width=\"20%\" bgcolor=\"#fade91\"><img src=\"http://mfm.com.my.tmp4.mschosting.com/userfiles/image/products/commercial%20products/noodles.gif\" width=\"120\" height=\"120\" /></td>\r\n<td style=\"text-align: center;\" width=\"20%\" bgcolor=\"#fade91\"><img src=\"http://mfm.com.my.tmp4.mschosting.com/userfiles/image/products/commercial%20products/cookies.gif\" width=\"120\" height=\"120\" />&nbsp;</td>\r\n<td style=\"text-align: center;\" width=\"20%\" bgcolor=\"#fade91\"><img src=\"http://mfm.com.my.tmp4.mschosting.com/userfiles/image/products/commercial%20products/flour_commercial-products(s.gif\" width=\"120\" height=\"120\" /></td>\r\n</tr>\r\n<tr>\r\n<td bgcolor=\"#fcf4d2\">\r\n<p style=\"text-align: center;\">&nbsp;<a href=\"index.php?p=contents-item&amp;id=277\" onclick=\"window.open(this.href,\'MalayanFlourMillsGoldenStatue\',\'resizable=no,location=no,menubar=no,scrollbars=yes,status=no,toolbar=no,fullscreen=no,dependent=no,width=500,height=500,left=200,top=100,status\'); return false\"><img src=\"http://mfm.com.my.tmp4.mschosting.com/userfiles/image/products-logo/gs_09.gif\" border=\"0\" /></a></p>\r\n<p style=\"text-align: center;\">Golden Statue</p>\r\n</td>\r\n<td bgcolor=\"#fcf4d2\">\r\n<p style=\"text-align: center;\">&nbsp;<a href=\"index.php?p=contents-item&amp;id=213\" onclick=\"window.open(this.href,\'MalayanflourMillsLoveBirds\',\'resizable=no,location=no,menubar=no,scrollbars=yes,status=no,toolbar=no,fullscreen=no,dependent=no,width=500,height=500,left=200,top=100,status\'); return false\"><img src=\"http://mfm.com.my.tmp4.mschosting.com/userfiles/image/products-logo/lovebirds_09.gif\" width=\"34\" border=\"0\" height=\"25\" /></a></p>\r\n<p style=\"text-align: center;\">Love Birds</p>\r\n</td>\r\n<td bgcolor=\"#fcf4d2\">\r\n<p style=\"text-align: center;\">&nbsp;<a href=\"index.php?p=contents-item&amp;id=210\" onclick=\"window.open(this.href,\'MalayanFlourMillsSPN\',\'resizable=no,location=no,menubar=no,scrollbars=yes,status=no,toolbar=no,fullscreen=no,dependent=no,width=500,height=500,left=200,top=100,status\'); return false\"><img src=\"http://mfm.com.my.tmp4.mschosting.com/userfiles/image/products-logo/spn_09.gif\" width=\"25\" border=\"0\" height=\"33\" /></a></p>\r\n<p style=\"text-align: center;\">SPN<br /> *for high-quality instant noodles</p>\r\n</td>\r\n<td bgcolor=\"#fcf4d2\">\r\n<p style=\"text-align: center;\">&nbsp;<img src=\"http://mfm.com.my.tmp4.mschosting.com/userfiles/image/products-logo/roses_09.gif\" width=\"34\" border=\"0\" height=\"25\" /></p>\r\n<p style=\"text-align: center;\">Red Roses</p>\r\n</td>\r\n<td bgcolor=\"#fcf4d2\">\r\n<p style=\"text-align: center;\">&nbsp;<a href=\"index.php?p=contents-item&amp;id=214\" onclick=\"window.open(this.href,\'MalayanFlourMillsRotiCanaiFlour\',\'resizable=no,location=no,menubar=no,scrollbars=yes,status=no,toolbar=no,fullscreen=no,dependent=no,width=500,height=500,left=200,top=100,status\'); return false\"><img src=\"http://mfm.com.my.tmp4.mschosting.com/userfiles/image/products-logo/roti-canai_09.gif\" width=\"25\" border=\"0\" height=\"33\" /></a></p>\r\n<p style=\"text-align: center;\">Roti Canai Flour</p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td style=\"text-align: center;\" bgcolor=\"#f8e9bf\">\r\n<p>&nbsp;<a onclick=\"window.open(this.href,\'MalayanFlourMillsDiamond\',\'resizable=no,location=no,menubar=no,scrollbars=yes,status=no,toolbar=no,fullscreen=no,dependent=no,width=500,height=500,left=200,top=100,status\'); return false\" href=\"index.php?p=contents-item&amp;id=211\"><img src=\"http://mfm.com.my.tmp4.mschosting.com/userfiles/image/products-logo/diamond_light_09.gif\" width=\"34\" border=\"0\" height=\"25\" /></a></p>\r\n<p>Diamond</p>\r\n</td>\r\n<td style=\"text-align: center;\" bgcolor=\"#f8e9bf\">\r\n<p>&nbsp;<a onclick=\"window.open(this.href,\'MalayanFlourMillsGoldenStatue\',\'resizable=no,location=no,menubar=no,scrollbars=yes,status=no,toolbar=no,fullscreen=no,dependent=no,width=500,height=500,left=200,top=100,status\'); return false\" href=\"index.php?p=contents-item&amp;id=277\"><img src=\"http://mfm.com.my.tmp4.mschosting.com/userfiles/image/products-logo/gs_09.gif\" width=\"20\" border=\"0\" height=\"33\" /></a></p>\r\n<p>Golden Statue</p>\r\n</td>\r\n<td style=\"text-align: center;\" bgcolor=\"#f8e9bf\">\r\n<p>&nbsp;<a onclick=\"window.open(this.href,\'MalayanFlourMillsRedBicycle\',\'resizable=no,location=no,menubar=no,scrollbars=yes,status=no,toolbar=no,fullscreen=no,dependent=no,width=500,height=500,left=200,top=100,status\'); return false\" href=\"index.php?p=contents-item&amp;id=216\"><img src=\"http://mfm.com.my.tmp4.mschosting.com/userfiles/image/products-logo/bicycle_light_09.gif\" width=\"34\" border=\"0\" height=\"25\" /></a></p>\r\n<p>Red Bicycle<br /> *for wet alkaline noodles</p>\r\n</td>\r\n<td style=\"text-align: center;\" bgcolor=\"#f8e9bf\">\r\n<p>&nbsp;<a onclick=\"window.open(this.href,\'MalayanFlourMillsYellowRoses\',\'resizable=no,location=no,menubar=no,scrollbars=yes,status=no,toolbar=no,fullscreen=no,dependent=no,width=500,height=500,left=200,top=100,status\'); return false\" href=\"index.php?p=contents-item&amp;id=219\"><img src=\"http://mfm.com.my.tmp4.mschosting.com/userfiles/image/products-logo/yellowrose_09.gif\" width=\"34\" border=\"0\" height=\"25\" /></a></p>\r\n<p>Yellow Roses</p>\r\n</td>\r\n<td bgcolor=\"#f8e9bf\">&nbsp;</td>\r\n</tr>\r\n<tr>\r\n<td style=\"text-align: center;\" bgcolor=\"#fcf4d2\">\r\n<p>&nbsp;<a href=\"index.php?p=contents-item&amp;id=212\" onclick=\"window.open(this.href,\'MalayanFlourMillsBalance\',\'resizable=no,location=no,menubar=no,scrollbars=yes,status=no,toolbar=no,fullscreen=no,dependent=no,width=500,height=500,left=200,top=100,status\'); return false\"><img src=\"http://mfm.com.my.tmp4.mschosting.com/userfiles/image/products-logo/balance_dark_09.gif\" width=\"34\" border=\"0\" height=\"25\" /></a></p>\r\n<p>Balance</p>\r\n</td>\r\n<td style=\"text-align: center;\" bgcolor=\"#fcf4d2\">\r\n<p>&nbsp;<a href=\"index.php?p=contents-item&amp;id=211\" onclick=\"window.open(this.href,\'MalayanFlourMillsDiamond\',\'resizable=no,location=no,menubar=no,scrollbars=yes,status=no,toolbar=no,fullscreen=no,dependent=no,width=500,height=500,left=200,top=100,status\'); return false\"><img src=\"http://mfm.com.my.tmp4.mschosting.com/userfiles/image/products-logo/diamond_light_09.gif\" width=\"34\" border=\"0\" height=\"25\" /></a></p>\r\n<p>Diamond</p>\r\n</td>\r\n<td style=\"text-align: center;\" bgcolor=\"#fcf4d2\">\r\n<p>&nbsp;<a href=\"index.php?p=contents-item&amp;id=212\" onclick=\"window.open(this.href,\'MalayanFlourMillsBalance\',\'resizable=no,location=no,menubar=no,scrollbars=yes,status=no,toolbar=no,fullscreen=no,dependent=no,width=500,height=500,left=200,top=100,status\'); return false\"><img src=\"http://mfm.com.my.tmp4.mschosting.com/userfiles/image/products-logo/balance_dark_09.gif\" width=\"34\" border=\"0\" height=\"25\" /></a></p>\r\n<p>Balance</p>\r\n</td>\r\n<td style=\"text-align: center;\" bgcolor=\"#fcf4d2\">\r\n<p>&nbsp;<a href=\"index.php?p=contents-item&amp;id=220\" onclick=\"window.open(this.href,\'MalayanFlourMillsSPIII\',\'resizable=no,location=no,menubar=no,scrollbars=yes,status=no,toolbar=no,fullscreen=no,dependent=no,width=500,height=500,left=200,top=100,status\'); return false\"><img src=\"http://mfm.com.my.tmp4.mschosting.com/userfiles/image/products-logo/sp3_09.gif\" width=\"25\" border=\"0\" height=\"33\" /></a></p>\r\n<p>SP III</p>\r\n</td>\r\n<td bgcolor=\"#fcf4d2\">&nbsp;</td>\r\n</tr>\r\n<tr>\r\n<td bgcolor=\"#f8e9bf\">&nbsp;</td>\r\n<td style=\"text-align: center;\" bgcolor=\"#f8e9bf\">\r\n<p>&nbsp;<a onclick=\"window.open(this.href,\'MalayanFlourMillsBlueRoses\',\'resizable=no,location=no,menubar=no,scrollbars=yes,status=no,toolbar=no,fullscreen=no,dependent=no,width=500,height=500,left=200,top=100,status\'); return false\" href=\"index.php?p=contents-item&amp;id=217\"><img src=\"http://mfm.com.my.tmp4.mschosting.com/userfiles/image/products-logo/bluerosses_dark_09.gif\" width=\"34\" border=\"0\" height=\"25\" /></a></p>\r\n<p>Blue Roses<br /> *for ‘Mee suah’</p>\r\n</td>\r\n<td style=\"text-align: center;\" bgcolor=\"#f8e9bf\">\r\n<p>&nbsp;<a onclick=\"window.open(this.href,\'MalayanFlourMillsBlueBicycle\',\'resizable=no,location=no,menubar=no,scrollbars=yes,status=no,toolbar=no,fullscreen=no,dependent=no,width=500,height=500,left=200,top=100,status\'); return false\" href=\"index.php?p=contents-item&amp;id=218\"><img src=\"http://mfm.com.my.tmp4.mschosting.com/userfiles/image/products-logo/bluebicycle_light_09.gif\" width=\"34\" border=\"0\" height=\"25\" /></a></p>\r\n<p>Blue Bicycle</p>\r\n</td>\r\n<td bgcolor=\"#f8e9bf\">&nbsp;</td>\r\n<td bgcolor=\"#f8e9bf\">&nbsp;</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<p> </p>\r\n<table id=\"table-frame\" width=\"100%\" border=\"0\" cellpadding=\"5\" cellspacing=\"0\">\r\n<tbody>\r\n<tr>\r\n<td width=\"25%\" align=\"center\" bgcolor=\"#fade91\"><strong>Pau/Steamed Bun&nbsp;</strong></td>\r\n<td width=\"25%\" align=\"center\" bgcolor=\"#fade91\"><strong>Wholemeal</strong> <strong>Bread</strong></td>\r\n<td width=\"25%\" align=\"center\" bgcolor=\"#fade91\"><strong>Loaf Cake</strong></td>\r\n<td width=\"25%\" align=\"center\" bgcolor=\"#fade91\"><strong>Roti Chapati and Puries</strong></td>\r\n</tr>\r\n<tr>\r\n<td width=\"25%\" align=\"center\" bgcolor=\"#fade91\"><img src=\"http://mfm.com.my.tmp4.mschosting.com/userfiles/image/products-logo/pau_.gif\" width=\"140\" border=\"0\" height=\"100\" />&nbsp;</td>\r\n<td width=\"25%\" align=\"center\" bgcolor=\"#fade91\">&nbsp;<img src=\"http://mfm.com.my.tmp4.mschosting.com/userfiles/image/products-logo/wholemeal.gif\" width=\"140\" border=\"0\" height=\"100\" /></td>\r\n<td width=\"25%\" align=\"center\" bgcolor=\"#fade91\">&nbsp;<img src=\"http://mfm.com.my.tmp4.mschosting.com/userfiles/image/products-logo/loaf-cake.gif\" width=\"140\" border=\"0\" height=\"100\" /></td>\r\n<td width=\"25%\" align=\"center\" bgcolor=\"#fade91\">&nbsp;<img src=\"http://mfm.com.my.tmp4.mschosting.com/userfiles/image/products-logo/roti-canai.gif\" width=\"140\" border=\"0\" height=\"100\" /></td>\r\n</tr>\r\n<tr>\r\n<td align=\"center\" bgcolor=\"#fcf4d2\">\r\n<p><a onclick=\"window.open(this.href,\'MalayanflourMIllsBlueRoses\',\'resizable=no,location=no,menubar=no,scrollbars=yes,status=no,toolbar=no,fullscreen=no,dependent=no,width=500,height=500,left=200,top=100,status\'); return false\" href=\"index.php?p=contents-item&amp;id=217\"><img src=\"http://mfm.com.my.tmp4.mschosting.com/userfiles/image/products-logo/bluerosses_dark_09.gif\" width=\"34\" border=\"0\" height=\"25\" /></a></p>\r\n<p>Blue Roses</p>\r\n</td>\r\n<td align=\"center\" bgcolor=\"#fcf4d2\">\r\n<p><a onclick=\"window.open(this.href,\'MalayanFlourMillsWholemeal\',\'resizable=no,location=no,menubar=no,scrollbars=yes,status=no,toolbar=no,fullscreen=no,dependent=no,width=500,height=500,left=200,top=100,status\'); return false\" href=\"index.php?p=contents-item&amp;id=243\"><img src=\"http://mfm.com.my.tmp4.mschosting.com/userfiles/image/products-logo/wholemeal09.gif\" width=\"25\" border=\"0\" height=\"33\" /></a></p>\r\n<p>Wholemeal</p>\r\n</td>\r\n<td align=\"center\" bgcolor=\"#fcf4d2\">\r\n<p><a onclick=\"window.open(this.href,\'MalayanFlourMillsBlueFlyingWheel\',\'resizable=no,location=no,menubar=no,scrollbars=yes,status=no,toolbar=no,fullscreen=no,dependent=no,width=500,height=500,left=200,top=100,status\'); return false\" href=\"index.php?p=contents-item&amp;id=245\"><img src=\"http://mfm.com.my.tmp4.mschosting.com/userfiles/image/products-logo/blue_semolina_light09.gif\" width=\"34\" border=\"0\" height=\"25\" /></a></p>\r\n<p>Blue Flying Wheel (Semolina)</p>\r\n</td>\r\n<td align=\"center\" bgcolor=\"#fcf4d2\">\r\n<p><a onclick=\"window.open(this.href,\'MalayanFlourMillsRedFlyingWheel\',\'resizable=no,location=no,menubar=no,scrollbars=yes,status=no,toolbar=no,fullscreen=no,dependent=no,width=500,height=500,left=200,top=100,status\'); return false\" href=\"index.php?p=contents-item&amp;id=246\"><img src=\"http://mfm.com.my.tmp4.mschosting.com/userfiles/image/products-logo/rw_attar_light09.gif\" width=\"34\" border=\"0\" height=\"25\" /></a></p>\r\n<p>Red Flying Wheel (Atta flour)</p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td align=\"center\" bgcolor=\"#f8e9bf\">&nbsp;</td>\r\n<td align=\"center\" bgcolor=\"#f8e9bf\">\r\n<p><a onclick=\"window.open(this.href,\'MalayanFlourMillsSpecialWholemeal\',\'resizable=no,location=no,menubar=no,scrollbars=yes,status=no,toolbar=no,fullscreen=no,dependent=no,width=500,height=500,left=200,top=100,status\'); return false\" href=\"index.php?p=contents-item&amp;id=244\"><img src=\"http://mfm.com.my.tmp4.mschosting.com/userfiles/image/products-logo/speacial_wholemeal09.gif\" width=\"30\" border=\"0\" height=\"33\" /></a></p>\r\n<p>Special Wholemeal</p>\r\n</td>\r\n<td align=\"center\" bgcolor=\"#f8e9bf\">&nbsp;</td>\r\n<td align=\"center\" bgcolor=\"#f8e9bf\">&nbsp;</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<p>* Highly recommended / Most Suitable</p>\r\n<br />', '', 1, 1, 0, 2, '2011-09-22 07:07:50', 62, '', '2011-09-22 08:37:57', 62, 0, '0000-00-00 00:00:00', '2011-09-22 07:07:50', '0000-00-00 00:00:00', '', '', 'show_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 3, 0, 3, '', '', 0, 11, 'robots=\nauthor='),
(2, 'Product test2', 'product-test2', '', '<span>Consumer Products</span>\r\n<hr />\r\n<span>Products</span><br />\r\n<p> </p>\r\n<p>MFM Brand is a range of 1kg pack flour that consists of 4 sub brands.</p>\r\n<table width=\"100%\" border=\"0\" cellpadding=\"5\" cellspacing=\"1\">\r\n<tbody>\r\n<tr>\r\n<td><img src=\"http://mfm.com.my.tmp4.mschosting.com/userfiles/image/peaches_.gif\" width=\"190\" height=\"315\" /></td>\r\n<td><strong>Brand</strong><br /> Peaches\r\n<p><strong>Type of Flour</strong><br /> Self-Raising</p>\r\n<p><strong>Usage</strong><br /> Pre-mixed with chemical leavening agents, this flour is suitable for baking quality sponge and chiffon cakes. This expertly blended and finely milled flour comes enriched with vitamins and iron.</p>\r\n<p><strong>Latest Promotion</strong><br /> <strong>FREE</strong>! 1 Recipe Booklet with every purchase of MFM Self-Raising Flour(1kg pack).<br /> Collect all 3 booklets.  Valid while stocks.</p>\r\n<p style=\"text-align: center;\"><img src=\"http://www.mfm.com.my/userfiles/image/flour-MFMbrand(1).jpg\" /></p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td colspan=\"2\">\r\n<hr />\r\n</td>\r\n</tr>\r\n<tr>\r\n<td><img src=\"http://mfm.com.my.tmp4.mschosting.com/userfiles/image/rose_.gif\" width=\"190\" height=\"315\" /></td>\r\n<td><strong>Brand</strong><br /> Red Roses\r\n<p><strong>Type of Flour</strong><br /> Superfine</p>\r\n<p><strong>Usage</strong><br /> A high quality, all purpose flour recommended to be used for baking cakes, tarts, pies and other pastries. It is also ideal for making doughnuts and home-made noodles. This finely milled quality flour comes enriched with vitamins and iron.</p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td colspan=\"2\">\r\n<hr />\r\n</td>\r\n</tr>\r\n<tr>\r\n<td><img src=\"http://mfm.com.my.tmp4.mschosting.com/userfiles/image/cempaka2(1).gif\" /></td>\r\n<td><strong>Brand</strong><br /> Bunga Cempaka\r\n<p><strong>Type of Flour</strong><br /> General Purpose</p>\r\n<p><strong>Usage</strong><br /> A specially milled general purpose flour used for making pancakes, cookies and ‘kuih-muih’. Also ideal for making batter for frying prawn, chicken and vegetables.</p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td colspan=\"2\">\r\n<hr />\r\n</td>\r\n</tr>\r\n<tr>\r\n<td><img src=\"http://mfm.com.my.tmp4.mschosting.com/userfiles/image/all_puposes2.gif\" width=\"190\" height=\"315\" /></td>\r\n<td><strong>Brand</strong><br /> MFM\r\n<p><strong>Type of Flour</strong><br /> All Purpose</p>\r\n<p><strong>Usage</strong><br /> Expertly blended, finely milled quality flour enriched with vitamins and iron. This flour is recommended for cakes, tarts, pies, doughnuts and other pastries. It is also used as thickener for gravies, sauces and soups.</p>\r\n</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<p> </p>\r\n<br />', '', 1, 1, 0, 2, '2011-09-22 07:10:54', 62, '', '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', '2011-09-22 07:10:54', '0000-00-00 00:00:00', '', '', 'show_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 1, 0, 2, '', '', 0, 0, 'robots=\nauthor='),
(3, 'Flour', 'flour', '', '<p>Products<br />We offer a wide range of wheat flour catering for every requirement. The products are categorized as follows:</p>\r\n<p>{loadposition flour}</p>', '', 1, 1, 0, 1, '2011-09-22 07:17:34', 62, '', '2011-09-22 07:28:09', 62, 0, '0000-00-00 00:00:00', '2011-09-22 07:17:34', '0000-00-00 00:00:00', '', '', 'show_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 3, 0, 1, '', '', 0, 90, 'robots=\nauthor='),
(4, 'abc', 'abc', '', '<div id=\"wrap\"><img src=\"http://www.mfm.com.my/templates/mountainfire/images/popup/popup-header.jpg\" border=\"0\" />\r\n<div class=\"clearfix\" id=\"main\">\r\n<div id=\"content-pane\"><span>Golden Statue</span>\r\n<hr />\r\n<p> </p>\r\n<table width=\"100%\" border=\"0\" cellpadding=\"5\" cellspacing=\"1\">\r\n<tbody>\r\n<tr>\r\n<td>Top grade, high-protein flour milled from best Canadian quality Hard Spring wheat. Excellent to be used for top quality bread, Wantan noodles, and extracting gluten for vegetarian food.\r\n<p>Packing Size = 25kg<br /> Packing Material = PP Woven Bag<br /> Protein = 12.5% - 13.5%</p>\r\n</td>\r\n<td><img src=\"http://mfm.com.my.tmp4.mschosting.com/userfiles/image/golden09.jpg\" /></td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<p> </p>\r\n<br />\r\n<div id=\"related-items\">\r\n<table id=\"related-items-style-outer\" width=\"100%\" border=\"0\" cellpadding=\"3\" cellspacing=\"2\">\r\n<tbody>\r\n<tr>\r\n<td><b>See Also</b></td>\r\n</tr>\r\n<tr>\r\n<td>\r\n<table id=\"related-items-style\" width=\"100%\" border=\"0\" cellpadding=\"6\" cellspacing=\"4\">\r\n<tbody>\r\n<tr>\r\n<td id=\"related-items-insidebox\" valign=\"top\" width=\"50%\" align=\"left\">\r\n<ul>\r\n<li><a href=\"index.php?p=contents-item&amp;id=218\">Blue Bicycle</a> </li>\r\n<li><a href=\"index.php?p=contents-item&amp;id=219\">Yellow Roses </a> </li>\r\n<li><a href=\"index.php?p=contents-item&amp;id=220\">SP III </a> </li>\r\n<li><a href=\"index.php?p=contents-item&amp;id=243\">Wholemeal</a> </li>\r\n<li><a href=\"index.php?p=contents-item&amp;id=244\">Special Wholemeal </a> </li>\r\n<li><a href=\"index.php?p=contents-item&amp;id=210\">SPN</a> </li>\r\n<li><a href=\"index.php?p=contents-item&amp;id=245\">Blue Flying Wheel (Semolina) </a> </li>\r\n<li><a href=\"index.php?p=contents-item&amp;id=211\">Diamond</a> </li>\r\n<li><a href=\"index.php?p=contents-item&amp;id=246\">Red Flying Wheel (Atta Flour)</a> </li>\r\n</ul>\r\n</td>\r\n<td id=\"related-items-insidebox\" valign=\"top\" width=\"50%\" align=\"left\">\r\n<ul>\r\n<li><a href=\"index.php?p=contents-item&amp;id=212\">Balance</a> </li>\r\n<li><a href=\"index.php?p=contents-item&amp;id=270\">Dove High Ratio Wheat Flour (Chlorinated)</a> </li>\r\n<li><a href=\"index.php?p=contents-item&amp;id=213\">Love Birds </a> </li>\r\n<li><a href=\"index.php?p=contents-item&amp;id=271\">Dove High Ratio Wheat Flour </a> </li>\r\n<li><a href=\"index.php?p=contents-item&amp;id=214\">Roti Canai Flour </a> </li>\r\n<li><a href=\"index.php?p=contents-item&amp;id=215\">Red Roses </a> </li>\r\n<li><a href=\"index.php?p=contents-item&amp;id=216\">Red Bicycle</a> </li>\r\n<li><a href=\"index.php?p=contents-item&amp;id=217\">Blue Roses</a> </li>\r\n</ul>\r\n</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n</div>\r\n</div>\r\n</div>\r\n</div>', '', 1, 1, 0, 2, '2011-09-22 08:27:24', 62, '', '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', '2011-09-22 08:27:24', '0000-00-00 00:00:00', '', '', 'show_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 1, 0, 1, '', '', 0, 46, 'robots=\nauthor=');

DROP TABLE IF EXISTS `jos_content_frontpage`;
CREATE TABLE `jos_content_frontpage` (
  `content_id` int(11) NOT NULL DEFAULT '0',
  `ordering` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`content_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `jos_content_rating`;
CREATE TABLE `jos_content_rating` (
  `content_id` int(11) NOT NULL DEFAULT '0',
  `rating_sum` int(11) unsigned NOT NULL DEFAULT '0',
  `rating_count` int(11) unsigned NOT NULL DEFAULT '0',
  `lastip` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`content_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `jos_core_acl_aro`;
CREATE TABLE `jos_core_acl_aro` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `section_value` varchar(240) NOT NULL DEFAULT '0',
  `value` varchar(240) NOT NULL DEFAULT '',
  `order_value` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `hidden` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `jos_section_value_value_aro` (`section_value`(100),`value`(100)),
  KEY `jos_gacl_hidden_aro` (`hidden`)
) ENGINE=MyISAM AUTO_INCREMENT=11 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `jos_core_acl_aro` VALUES
(10, 'users', '62', 0, 'Administrator', 0);

DROP TABLE IF EXISTS `jos_core_acl_aro_groups`;
CREATE TABLE `jos_core_acl_aro_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `lft` int(11) NOT NULL DEFAULT '0',
  `rgt` int(11) NOT NULL DEFAULT '0',
  `value` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `jos_gacl_parent_id_aro_groups` (`parent_id`),
  KEY `jos_gacl_lft_rgt_aro_groups` (`lft`,`rgt`)
) ENGINE=MyISAM AUTO_INCREMENT=31 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `jos_core_acl_aro_groups` VALUES
(17, 0, 'ROOT', 1, 22, 'ROOT'),
(28, 17, 'USERS', 2, 21, 'USERS'),
(29, 28, 'Public Frontend', 3, 12, 'Public Frontend'),
(18, 29, 'Registered', 4, 11, 'Registered'),
(19, 18, 'Author', 5, 10, 'Author'),
(20, 19, 'Editor', 6, 9, 'Editor'),
(21, 20, 'Publisher', 7, 8, 'Publisher'),
(30, 28, 'Public Backend', 13, 20, 'Public Backend'),
(23, 30, 'Manager', 14, 19, 'Manager'),
(24, 23, 'Administrator', 15, 18, 'Administrator'),
(25, 24, 'Super Administrator', 16, 17, 'Super Administrator');

DROP TABLE IF EXISTS `jos_core_acl_aro_map`;
CREATE TABLE `jos_core_acl_aro_map` (
  `acl_id` int(11) NOT NULL DEFAULT '0',
  `section_value` varchar(230) NOT NULL DEFAULT '0',
  `value` varchar(100) NOT NULL,
  PRIMARY KEY (`acl_id`,`section_value`,`value`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `jos_core_acl_aro_sections`;
CREATE TABLE `jos_core_acl_aro_sections` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `value` varchar(230) NOT NULL DEFAULT '',
  `order_value` int(11) NOT NULL DEFAULT '0',
  `name` varchar(230) NOT NULL DEFAULT '',
  `hidden` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `jos_gacl_value_aro_sections` (`value`),
  KEY `jos_gacl_hidden_aro_sections` (`hidden`)
) ENGINE=MyISAM AUTO_INCREMENT=11 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `jos_core_acl_aro_sections` VALUES
(10, 'users', 1, 'Users', 0);

DROP TABLE IF EXISTS `jos_core_acl_groups_aro_map`;
CREATE TABLE `jos_core_acl_groups_aro_map` (
  `group_id` int(11) NOT NULL DEFAULT '0',
  `section_value` varchar(240) NOT NULL DEFAULT '',
  `aro_id` int(11) NOT NULL DEFAULT '0',
  UNIQUE KEY `group_id_aro_id_groups_aro_map` (`group_id`,`section_value`,`aro_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `jos_core_acl_groups_aro_map` VALUES
(25, '', 10);

DROP TABLE IF EXISTS `jos_core_log_items`;
CREATE TABLE `jos_core_log_items` (
  `time_stamp` date NOT NULL DEFAULT '0000-00-00',
  `item_table` varchar(50) NOT NULL DEFAULT '',
  `item_id` int(11) unsigned NOT NULL DEFAULT '0',
  `hits` int(11) unsigned NOT NULL DEFAULT '0'
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `jos_core_log_searches`;
CREATE TABLE `jos_core_log_searches` (
  `search_term` varchar(128) NOT NULL DEFAULT '',
  `hits` int(11) unsigned NOT NULL DEFAULT '0'
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `jos_groups`;
CREATE TABLE `jos_groups` (
  `id` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `name` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `jos_groups` VALUES
(0, 'Public'),
(1, 'Registered'),
(2, 'Special');

DROP TABLE IF EXISTS `jos_jce_groups`;
CREATE TABLE `jos_jce_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `users` text NOT NULL,
  `types` varchar(255) NOT NULL,
  `components` text NOT NULL,
  `rows` text NOT NULL,
  `plugins` varchar(255) NOT NULL,
  `published` tinyint(3) NOT NULL,
  `ordering` int(11) NOT NULL,
  `checked_out` tinyint(3) NOT NULL,
  `checked_out_time` datetime NOT NULL,
  `params` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `jos_jce_groups` VALUES
(1, 'Default', 'Default group for all users with edit access', '', '19,20,21,23,24,25', '', '6,7,8,9,10,11,12,13,14,15,16,17,18,19;20,21,22,23,24,25,26,27,28,30,31,32,35,47;36,37,38,39,40,41,42,43,44,45,46;48,49,50,51,52,53,54,56,57', '1,2,3,4,5,6,20,21,36,37,38,39,40,41,48,49,50,51,52,53,54,56,57', 1, 1, 0, '0000-00-00 00:00:00', ''),
(2, 'Front End', 'Sample Group for Authors, Editors, Publishers', '', '19,20,21', '', '6,7,8,9,10,13,14,15,16,17,18,19,27,28;20,21,25,26,30,31,35,42,43,44,46,47,49,50;24,32,38,39,41,45,48,51,52,53,54,56,57', '6,20,21,49,50,1,3,5,38,39,41,48,51,52,53,54,56,57', 0, 2, 0, '0000-00-00 00:00:00', '');

DROP TABLE IF EXISTS `jos_jce_plugins`;
CREATE TABLE `jos_jce_plugins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `icon` varchar(255) NOT NULL,
  `layout` varchar(255) NOT NULL,
  `row` int(11) NOT NULL,
  `ordering` int(11) NOT NULL,
  `published` tinyint(3) NOT NULL,
  `editable` tinyint(3) NOT NULL,
  `iscore` tinyint(3) NOT NULL,
  `elements` varchar(255) NOT NULL,
  `checked_out` int(11) NOT NULL,
  `checked_out_time` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `plugin` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=58 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `jos_jce_plugins` VALUES
(1, 'Context Menu', 'contextmenu', 'plugin', '', '', 0, 0, 1, 0, 1, '', 0, '0000-00-00 00:00:00'),
(2, 'File Browser', 'browser', 'plugin', '', '', 0, 0, 1, 1, 1, '', 0, '0000-00-00 00:00:00'),
(3, 'Inline Popups', 'inlinepopups', 'plugin', '', '', 0, 0, 1, 0, 1, '', 0, '0000-00-00 00:00:00'),
(4, 'Media Support', 'media', 'plugin', '', '', 0, 0, 1, 1, 1, '', 0, '0000-00-00 00:00:00'),
(5, 'Safari Browser Support', 'safari', 'plugin', '', '', 0, 0, 1, 0, 1, '', 0, '0000-00-00 00:00:00'),
(6, 'Help', 'help', 'plugin', 'help', 'help', 1, 1, 1, 0, 1, '', 0, '0000-00-00 00:00:00'),
(7, 'New Document', 'newdocument', 'command', 'newdocument', 'newdocument', 1, 2, 1, 0, 1, '', 0, '0000-00-00 00:00:00'),
(8, 'Bold', 'bold', 'command', 'bold', 'bold', 1, 3, 1, 0, 1, '', 0, '0000-00-00 00:00:00'),
(9, 'Italic', 'italic', 'command', 'italic', 'italic', 1, 4, 1, 0, 1, '', 0, '0000-00-00 00:00:00'),
(10, 'Underline', 'underline', 'command', 'underline', 'underline', 1, 5, 1, 0, 1, '', 0, '0000-00-00 00:00:00'),
(11, 'Font Select', 'fontselect', 'command', 'fontselect', 'fontselect', 1, 6, 1, 0, 1, '', 0, '0000-00-00 00:00:00'),
(12, 'Font Size Select', 'fontsizeselect', 'command', 'fontsizeselect', 'fontsizeselect', 1, 7, 1, 0, 1, '', 0, '0000-00-00 00:00:00'),
(13, 'Style Select', 'styleselect', 'command', 'styleselect', 'styleselect', 1, 8, 1, 0, 1, '', 0, '0000-00-00 00:00:00'),
(14, 'StrikeThrough', 'strikethrough', 'command', 'strikethrough', 'strikethrough', 1, 9, 1, 0, 1, '', 0, '0000-00-00 00:00:00'),
(15, 'Justify Full', 'full', 'command', 'justifyfull', 'justifyfull', 1, 10, 1, 0, 1, '', 0, '0000-00-00 00:00:00'),
(16, 'Justify Center', 'center', 'command', 'justifycenter', 'justifycenter', 1, 11, 1, 0, 1, '', 0, '0000-00-00 00:00:00'),
(17, 'Justify Left', 'left', 'command', 'justifyleft', 'justifyleft', 1, 12, 1, 0, 1, '', 0, '0000-00-00 00:00:00'),
(18, 'Justify Right', 'right', 'command', 'justifyright', 'justifyright', 1, 13, 1, 0, 1, '', 0, '0000-00-00 00:00:00'),
(19, 'Format Select', 'formatselect', 'command', 'formatselect', 'formatselect', 1, 14, 1, 0, 1, '', 0, '0000-00-00 00:00:00'),
(20, 'Paste', 'paste', 'plugin', 'cut,copy,paste', 'paste', 2, 1, 1, 1, 1, '', 0, '0000-00-00 00:00:00'),
(21, 'Search Replace', 'searchreplace', 'plugin', 'search,replace', 'searchreplace', 2, 2, 1, 0, 1, '', 0, '0000-00-00 00:00:00'),
(22, 'Font ForeColour', 'forecolor', 'command', 'forecolor', 'forecolor', 2, 3, 1, 0, 1, '', 0, '0000-00-00 00:00:00'),
(23, 'Font BackColour', 'backcolor', 'command', 'backcolor', 'backcolor', 2, 4, 1, 0, 1, '', 0, '0000-00-00 00:00:00'),
(24, 'Unlink', 'unlink', 'command', 'unlink', 'unlink', 2, 5, 1, 0, 1, '', 0, '0000-00-00 00:00:00'),
(25, 'Indent', 'indent', 'command', 'indent', 'indent', 2, 6, 1, 0, 1, '', 0, '0000-00-00 00:00:00'),
(26, 'Outdent', 'outdent', 'command', 'outdent', 'outdent', 2, 7, 1, 0, 1, '', 0, '0000-00-00 00:00:00'),
(27, 'Undo', 'undo', 'command', 'undo', 'undo', 2, 8, 1, 0, 1, '', 0, '0000-00-00 00:00:00'),
(28, 'Redo', 'redo', 'command', 'redo', 'redo', 2, 9, 1, 0, 1, '', 0, '0000-00-00 00:00:00'),
(29, 'HTML', 'html', 'command', 'code', 'code', 2, 10, 1, 0, 1, '', 0, '0000-00-00 00:00:00'),
(30, 'Numbered List', 'numlist', 'command', 'numlist', 'numlist', 2, 11, 1, 0, 1, '', 0, '0000-00-00 00:00:00'),
(31, 'Bullet List', 'bullist', 'command', 'bullist', 'bullist', 2, 12, 1, 0, 1, '', 0, '0000-00-00 00:00:00'),
(32, 'Anchor', 'anchor', 'command', 'anchor', 'anchor', 2, 13, 1, 0, 1, '', 0, '0000-00-00 00:00:00'),
(33, 'Image', 'image', 'command', 'image', 'image', 2, 14, 1, 0, 1, '', 0, '0000-00-00 00:00:00'),
(34, 'Link', 'link', 'command', 'link', 'link', 2, 15, 1, 0, 1, '', 0, '0000-00-00 00:00:00'),
(35, 'Code Cleanup', 'cleanup', 'command', 'cleanup', 'cleanup', 2, 16, 1, 0, 1, '', 0, '0000-00-00 00:00:00'),
(36, 'Directionality', 'directionality', 'plugin', 'ltr,rtl', 'directionality', 3, 1, 1, 0, 1, '', 0, '0000-00-00 00:00:00'),
(37, 'Emotions', 'emotions', 'plugin', 'emotions', 'emotions', 3, 2, 1, 0, 1, '', 0, '0000-00-00 00:00:00'),
(38, 'Fullscreen', 'fullscreen', 'plugin', 'fullscreen', 'fullscreen', 3, 3, 1, 0, 1, '', 0, '0000-00-00 00:00:00'),
(39, 'Preview', 'preview', 'plugin', 'preview', 'preview', 3, 4, 1, 0, 1, '', 0, '0000-00-00 00:00:00'),
(40, 'Tables', 'table', 'plugin', 'tablecontrols', 'buttons', 3, 5, 1, 0, 1, '', 0, '0000-00-00 00:00:00'),
(41, 'Print', 'print', 'plugin', 'print', 'print', 3, 6, 1, 0, 1, '', 0, '0000-00-00 00:00:00'),
(42, 'Horizontal Rule', 'hr', 'command', 'hr', 'hr', 3, 7, 1, 0, 1, '', 0, '0000-00-00 00:00:00'),
(43, 'Subscript', 'sub', 'command', 'sub', 'sub', 3, 8, 1, 0, 1, '', 0, '0000-00-00 00:00:00'),
(44, 'Superscript', 'sup', 'command', 'sup', 'sup', 3, 9, 1, 0, 1, '', 0, '0000-00-00 00:00:00'),
(45, 'Visual Aid', 'visualaid', 'command', 'visualaid', 'visualaid', 3, 10, 1, 0, 1, '', 0, '0000-00-00 00:00:00'),
(46, 'Character Map', 'charmap', 'command', 'charmap', 'charmap', 3, 11, 1, 0, 1, '', 0, '0000-00-00 00:00:00'),
(47, 'Remove Format', 'removeformat', 'command', 'removeformat', 'removeformat', 2, 1, 1, 0, 1, '', 0, '0000-00-00 00:00:00'),
(48, 'Styles', 'style', 'plugin', 'styleprops', 'style', 4, 1, 1, 0, 1, '', 0, '0000-00-00 00:00:00'),
(49, 'Non-Breaking', 'nonbreaking', 'plugin', 'nonbreaking', 'nonbreaking', 4, 2, 1, 0, 1, '', 0, '0000-00-00 00:00:00'),
(50, 'Visual Characters', 'visualchars', 'plugin', 'visualchars', 'visualchars', 4, 3, 1, 0, 1, '', 0, '0000-00-00 00:00:00'),
(51, 'XHTML Xtras', 'xhtmlxtras', 'plugin', 'cite,abbr,acronym,del,ins,attribs', 'xhtmlxtras', 4, 4, 1, 0, 1, '', 0, '0000-00-00 00:00:00'),
(52, 'Image Manager', 'imgmanager', 'plugin', 'imgmanager', 'imgmanager', 4, 5, 1, 1, 1, '', 0, '0000-00-00 00:00:00'),
(53, 'Advanced Link', 'advlink', 'plugin', 'advlink', 'advlink', 4, 6, 1, 1, 1, '', 0, '0000-00-00 00:00:00'),
(54, 'Spell Checker', 'spellchecker', 'plugin', 'spellchecker', 'spellchecker', 4, 7, 1, 1, 1, '', 0, '0000-00-00 00:00:00'),
(55, 'Layers', 'layer', 'plugin', 'insertlayer,moveforward,movebackward,absolute', 'layer', 4, 8, 1, 0, 1, '', 0, '0000-00-00 00:00:00'),
(56, 'Advanced Code Editor', 'advcode', 'plugin', 'advcode', 'advcode', 4, 9, 1, 0, 1, '', 0, '0000-00-00 00:00:00'),
(57, 'Article Breaks', 'article', 'plugin', 'readmore,pagebreak', 'article', 4, 10, 1, 0, 1, '', 0, '0000-00-00 00:00:00');

DROP TABLE IF EXISTS `jos_jf_content`;
CREATE TABLE `jos_jf_content` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `language_id` int(11) NOT NULL DEFAULT '0',
  `reference_id` int(11) NOT NULL DEFAULT '0',
  `reference_table` varchar(100) NOT NULL DEFAULT '',
  `reference_field` varchar(100) NOT NULL DEFAULT '',
  `value` mediumtext NOT NULL,
  `original_value` varchar(255) DEFAULT NULL,
  `original_text` mediumtext,
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(11) unsigned NOT NULL DEFAULT '0',
  `published` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `combo` (`reference_id`,`reference_field`,`reference_table`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `jos_jf_tableinfo`;
CREATE TABLE `jos_jf_tableinfo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `joomlatablename` varchar(100) NOT NULL DEFAULT '',
  `tablepkID` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `jos_languages`;
CREATE TABLE `jos_languages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL DEFAULT '',
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `iso` varchar(20) DEFAULT NULL,
  `code` varchar(20) NOT NULL DEFAULT '',
  `shortcode` varchar(20) DEFAULT NULL,
  `image` varchar(100) DEFAULT NULL,
  `fallback_code` varchar(20) NOT NULL DEFAULT '',
  `params` text NOT NULL,
  `ordering` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `jos_languages` VALUES
(1, 'English (United Kingdom)', 1, 'en_GB.utf8, en_GB.UT', 'en-GB', 'en', '', '', '', 1);

DROP TABLE IF EXISTS `jos_menu`;
CREATE TABLE `jos_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `menutype` varchar(75) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `alias` varchar(255) NOT NULL DEFAULT '',
  `link` text,
  `type` varchar(50) NOT NULL DEFAULT '',
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `parent` int(11) unsigned NOT NULL DEFAULT '0',
  `componentid` int(11) unsigned NOT NULL DEFAULT '0',
  `sublevel` int(11) DEFAULT '0',
  `ordering` int(11) DEFAULT '0',
  `checked_out` int(11) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pollid` int(11) NOT NULL DEFAULT '0',
  `browserNav` tinyint(4) DEFAULT '0',
  `access` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `utaccess` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `params` text NOT NULL,
  `lft` int(11) unsigned NOT NULL DEFAULT '0',
  `rgt` int(11) unsigned NOT NULL DEFAULT '0',
  `home` int(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `componentid` (`componentid`,`menutype`,`published`,`access`),
  KEY `menutype` (`menutype`)
) ENGINE=MyISAM AUTO_INCREMENT=8 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `jos_menu` VALUES
(1, 'mainmenu', 'Home', 'home', 'index.php?option=com_content&view=frontpage', 'component', 1, 0, 20, 0, 1, 0, '0000-00-00 00:00:00', 0, 0, 0, 3, 'num_leading_articles=1\nnum_intro_articles=4\nnum_columns=2\nnum_links=4\norderby_pri=\norderby_sec=front\nmulti_column_order=1\nshow_pagination=2\nshow_pagination_results=1\nshow_feed_link=1\nshow_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nshow_hits=\nfeed_summary=\npage_title=\nshow_page_title=0\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 1),
(2, 'mainmenu', 'Core Business', 'ore-business', 'index.php?option=com_content&view=article&id=3', 'component', 1, 0, 20, 0, 2, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'show_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nshow_hits=\nfeed_summary=\npage_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(3, 'mainmenu', 'Contact Us', 'contact-us', 'index.php?option=com_contact&view=contact&id=1', 'component', 1, 0, 7, 0, 3, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'show_contact_list=0\nshow_category_crumb=0\ncontact_icons=\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_headings=\nshow_position=\nshow_email=\nshow_telephone=\nshow_mobile=\nshow_fax=\nallow_vcard=\nbanned_email=\nbanned_subject=\nbanned_text=\nvalidate_session=\ncustom_reply=\npage_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(4, 'mainmenu', 'Core Business', 'ore-business', 'index.php?option=com_content&view=article&id=3', 'component', 1, 2, 20, 1, 1, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'show_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nshow_hits=\nfeed_summary=\npage_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(5, 'mainmenu', 'Contact Us', 'contact-us', 'index.php?option=com_contact&view=contact&id=1', 'component', 1, 2, 7, 1, 2, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'show_contact_list=0\nshow_category_crumb=0\ncontact_icons=\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_headings=\nshow_position=\nshow_email=\nshow_telephone=\nshow_mobile=\nshow_fax=\nallow_vcard=\nbanned_email=\nbanned_subject=\nbanned_text=\nvalidate_session=\ncustom_reply=\npage_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(6, 'mainmenu', 'Core Business', 'ore-business', 'index.php?option=com_content&view=article&id=3', 'component', 1, 5, 20, 2, 1, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'show_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nshow_hits=\nfeed_summary=\npage_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(7, 'mainmenu', 'Contact Us', 'contact-us', 'index.php?option=com_contact&view=contact&id=1', 'component', 1, 5, 7, 2, 2, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'show_contact_list=0\nshow_category_crumb=0\ncontact_icons=\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_headings=\nshow_position=\nshow_email=\nshow_telephone=\nshow_mobile=\nshow_fax=\nallow_vcard=\nbanned_email=\nbanned_subject=\nbanned_text=\nvalidate_session=\ncustom_reply=\npage_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0);

DROP TABLE IF EXISTS `jos_menu_types`;
CREATE TABLE `jos_menu_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `menutype` varchar(75) NOT NULL DEFAULT '',
  `title` varchar(255) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `menutype` (`menutype`)
) ENGINE=MyISAM AUTO_INCREMENT=2 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `jos_menu_types` VALUES
(1, 'mainmenu', 'Main Menu', 'The main menu for the site');

DROP TABLE IF EXISTS `jos_messages`;
CREATE TABLE `jos_messages` (
  `message_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id_from` int(10) unsigned NOT NULL DEFAULT '0',
  `user_id_to` int(10) unsigned NOT NULL DEFAULT '0',
  `folder_id` int(10) unsigned NOT NULL DEFAULT '0',
  `date_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `state` int(11) NOT NULL DEFAULT '0',
  `priority` int(1) unsigned NOT NULL DEFAULT '0',
  `subject` text NOT NULL,
  `message` text NOT NULL,
  PRIMARY KEY (`message_id`),
  KEY `useridto_state` (`user_id_to`,`state`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `jos_messages_cfg`;
CREATE TABLE `jos_messages_cfg` (
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `cfg_name` varchar(100) NOT NULL DEFAULT '',
  `cfg_value` varchar(255) NOT NULL DEFAULT '',
  UNIQUE KEY `idx_user_var_name` (`user_id`,`cfg_name`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `jos_migration_backlinks`;
CREATE TABLE `jos_migration_backlinks` (
  `itemid` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `url` text NOT NULL,
  `sefurl` text NOT NULL,
  `newurl` text NOT NULL,
  PRIMARY KEY (`itemid`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `jos_modules`;
CREATE TABLE `jos_modules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` text NOT NULL,
  `content` text NOT NULL,
  `ordering` int(11) NOT NULL DEFAULT '0',
  `position` varchar(50) DEFAULT NULL,
  `checked_out` int(11) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `module` varchar(50) DEFAULT NULL,
  `numnews` int(11) NOT NULL DEFAULT '0',
  `access` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `showtitle` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `params` text NOT NULL,
  `iscore` tinyint(4) NOT NULL DEFAULT '0',
  `client_id` tinyint(4) NOT NULL DEFAULT '0',
  `control` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `published` (`published`,`access`),
  KEY `newsfeeds` (`module`,`published`)
) ENGINE=MyISAM AUTO_INCREMENT=34 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `jos_modules` VALUES
(1, 'Main Menu', '', 0, 'menu', 0, '0000-00-00 00:00:00', 1, 'mod_mainmenu', 0, 0, 0, 'menutype=mainmenu\nmenu_style=list\nstartLevel=0\nendLevel=0\nshowAllChildren=1\nwindow_open=\nshow_whitespace=0\ncache=1\ntag_id=\nclass_sfx=\nmoduleclass_sfx= clearfix\nmaxdepth=10\nmenu_images=0\nmenu_images_align=0\nmenu_images_link=0\nexpand_menu=0\nactivate_parent=0\nfull_active_id=0\nindent_image=0\nindent_image1=\nindent_image2=\nindent_image3=\nindent_image4=\nindent_image5=\nindent_image6=\nspacer=\nend_spacer=\n\n', 1, 0, ''),
(2, 'Login', '', 1, 'login', 0, '0000-00-00 00:00:00', 1, 'mod_login', 0, 0, 1, '', 1, 1, ''),
(3, 'Popular', '', 3, 'cpanel', 0, '0000-00-00 00:00:00', 1, 'mod_popular', 0, 2, 1, '', 0, 1, ''),
(4, 'Recent added Articles', '', 4, 'cpanel', 0, '0000-00-00 00:00:00', 1, 'mod_latest', 0, 2, 1, 'ordering=c_dsc\nuser_id=0\ncache=0\n\n', 0, 1, ''),
(5, 'Menu Stats', '', 5, 'cpanel', 0, '0000-00-00 00:00:00', 1, 'mod_stats', 0, 2, 1, '', 0, 1, ''),
(6, 'Unread Messages', '', 1, 'header', 0, '0000-00-00 00:00:00', 1, 'mod_unread', 0, 2, 1, '', 1, 1, ''),
(7, 'Online Users', '', 2, 'header', 0, '0000-00-00 00:00:00', 1, 'mod_online', 0, 2, 1, '', 1, 1, ''),
(8, 'Toolbar', '', 1, 'toolbar', 0, '0000-00-00 00:00:00', 1, 'mod_toolbar', 0, 2, 1, '', 1, 1, ''),
(9, 'Quick Icons', '', 1, 'icon', 0, '0000-00-00 00:00:00', 1, 'mod_quickicon', 0, 2, 1, '', 1, 1, ''),
(10, 'Logged in Users', '', 2, 'cpanel', 0, '0000-00-00 00:00:00', 1, 'mod_logged', 0, 2, 1, '', 0, 1, ''),
(11, 'Footer', '', 0, 'footer', 0, '0000-00-00 00:00:00', 1, 'mod_footer', 0, 0, 1, '', 1, 1, ''),
(12, 'Admin Menu', '', 1, 'menu', 0, '0000-00-00 00:00:00', 1, 'mod_menu', 0, 2, 1, '', 0, 1, ''),
(13, 'Admin SubMenu', '', 1, 'submenu', 0, '0000-00-00 00:00:00', 1, 'mod_submenu', 0, 2, 1, '', 0, 1, ''),
(14, 'User Status', '', 1, 'status', 0, '0000-00-00 00:00:00', 1, 'mod_status', 0, 2, 1, '', 0, 1, ''),
(15, 'Title', '', 1, 'title', 0, '0000-00-00 00:00:00', 1, 'mod_title', 0, 2, 1, '', 0, 1, ''),
(16, 'Nivo-Szaki Slider', '', 0, 'banner', 0, '0000-00-00 00:00:00', 1, 'mod_nivoslider', 0, 0, 0, 'moduleclass_sfx=\nimagesDir=images/stories/mekong/banner\nsubDir=0\nimagesAttributes=Array\ntarget=_self\nstyle=enhanced\ncustomStyle=\nsoundFX=0\nsound=nivo-szakislider.ogg\nsoundVol=1\neffect=random\nslices=15\nanimSpeed=500\npauseTime=3000\nstartSlide=0\ndirectionNav=1\ndirectionNavHide=1\ncontrolNav=0\ncontrolNavThumbs=0\ncontrolNavThumbsSearch=.jpg\ncontrolNavThumbsReplace=_thumb.jpg\nkeyboardNav=1\npauseOnHover=1\nmanualAdvance=0\ncaptionOpacity=0.8\njQuery=1\ncache=1\ncache_time=900\n\n', 0, 0, ''),
(17, 'Lnag', '<img src=\"images/stories/mekong/lang.png\" />', 0, 'lang', 0, '0000-00-00 00:00:00', 1, 'mod_custom', 0, 0, 0, 'moduleclass_sfx=\n\n', 0, 0, ''),
(18, 'Search', '', 0, 'search', 0, '0000-00-00 00:00:00', 1, 'mod_search', 0, 0, 0, 'moduleclass_sfx=\nwidth=20\ntext=\nbutton=1\nbutton_pos=right\nimagebutton=\nbutton_text=Search\nset_itemid=\ncache=1\ncache_time=900\n\n', 0, 0, ''),
(19, 'About us', '<p>Welcome to MeKong Flour Mills!</p>\r\n<p>Welcome to MeKong Flour Mills!Welcome to MeKong Flour Mills!Welcome to MeKong Flour Mills!Welcome to MeKong Flour Mills!Welcome to MeKong Flour Mills!Welcome to MeKong Flour Mills!Welcome to MeKong Flour Mills!Welcome to MeKong Flour Mills!Welcome to MeKong Flour Mills!Welcome to MeKong Flour Mills!Welcome to MeKong Flour Mills!Welcome to MeKong Flour Mills!Welcome to MeKong Flour Mills!Welcome to MeKong Flour Mills!Welcome to MeKong Flour Mills!Welcome to MeKong Flour Mills!Welcome to MeKong Flour Mills!Welcome to MeKong Flour Mills!Welcome to MeKong Flour Mills!Welcome to MeKong Flour Mills!Welcome to MeKong Flour Mills!Welcome to MeKong Flour Mills!Welcome to MeKong Flour Mills!Welcome to MeKong Flour Mills!</p>', 0, 'gioithieu', 0, '0000-00-00 00:00:00', 1, 'mod_custom', 0, 0, 1, 'moduleclass_sfx=\n\n', 0, 0, ''),
(20, 'Vinaora Visitors Counter', '', -1, 'luottruycap', 0, '0000-00-00 00:00:00', 1, 'mod_vvisit_counter', 0, 0, 0, 'moduleclass_sfx=\nmode=custom\ninitialvalue=0\ndigit_type=default\nnumber_digits=6\nstats_type=default\nwidthtable=90\ntoday=0\nyesterday=0\nweek=0\nlweek=0\nmonth=0\nlmonth=0\nall=0\nautohide=0\nhrline=1\nbeginday=\nonline=0\nguestip=0\nguestinfo=0\nformattime=0\nissunday=1\ncache_time=15\npretext=\nposttext=\n\n', 0, 0, ''),
(21, 'Ad tfooter', '<img src=\"images/stories/mekong/tfooter.png\" />', 0, 'tfooter', 0, '0000-00-00 00:00:00', 1, 'mod_custom', 0, 0, 0, 'moduleclass_sfx=\n\n', 0, 0, ''),
(22, 'Copyright', 'Copyright 2011<br />', 1, 'copyright', 0, '0000-00-00 00:00:00', 1, 'mod_custom', 0, 0, 0, 'moduleclass_sfx=\n\n', 0, 0, ''),
(23, 'Banner 2', '<img src=\"images/stories/mekong/banner2/b1.png\" />', 0, 'img-link', 0, '0000-00-00 00:00:00', 1, 'mod_custom', 0, 0, 0, 'moduleclass_sfx= bn2\n\n', 0, 0, ''),
(24, 'gototop', 'Go to Top <img src=\"images/stories/mekong/top.png\" />', 0, 'gotop', 0, '0000-00-00 00:00:00', 1, 'mod_custom', 0, 0, 0, 'moduleclass_sfx=\n\n', 0, 0, ''),
(32, 'Language Selection', '', -1, 'user4', 0, '0000-00-00 00:00:00', 0, 'mod_jflanguageselection', 0, 0, 0, '', 0, 0, ''),
(33, 'Direct Translation', '', 0, 'status', 0, '0000-00-00 00:00:00', 1, 'mod_translate', 0, 2, 0, 'linktype=squeezebox\ncomponents=com_content#content#cid#task#!edit|com_frontpage#content#cid#task#!edit|com_sections#sections#cid#task#!edit|com_categories#categories#cid#task#!edit|com_contact#contact_details#cid#!edit|com_menus#menu#cid#task#!edit|com_modules#modules#cid#task#!edit#client#!1|com_newsfeeds#newsfeeds#cid#task#!edit|com_poll#polls#cid#task#!edit||||||||||', 0, 1, ''),
(27, '2J Tabs', '', 3, 'flour', 0, '0000-00-00 00:00:00', 1, 'mod_2j_tabs', 0, 0, 1, 'moduleclass_sfx=\ncat_or_sec=0\ncatid=2\nsecid=0\nload_module=flour\nload_module_style=-2\ncontent_count_word=\ncontent_count_cut_word=1\ncontent_count_cut_text=\nimage=1\nshow_autor=0\nshow_created=0\nshow_modified=0\nshow_fulltext=0\nitem_title=1\nlink_titles=0\nreadmore=0\nitems=0\nitems_inpage=\norderby=0\nall_width=\nall_height=\ndiv_height=\npend_all_left=\npend_all_right=\npend_all_top=\npend_all_bottom=\ntitleintab=0\ntab_template=Tab #\ncustom_label=\ntab_name_cut=\ntab_name_cut_text=\nselect_def=\npage_bar=0\nalign_tab=0\nch_tabs=0\nenable_hover=0\nfont_tab=\nfont_size_tab=\npending_need=0\npend_li_left=\npend_li_right=\npend_ul_left=\npend_ul_right=\npre_text=\npost_text=\ntemplate=\nbg_color=\nstyle=1\nshow_border=0\ncolor_border=#000000\neffect=0\nduration=200\nxhtml=0\ntimer=0\ntimer_time=3000\ntwoj_ajax_admin=2\n\n', 0, 0, ''),
(31, 'Core Business', '', 0, 'left', 0, '0000-00-00 00:00:00', 1, 'mod_mainmenu', 0, 0, 1, 'menutype=mainmenu\nmenu_style=list\nstartLevel=1\nendLevel=3\nshowAllChildren=1\nwindow_open=\nshow_whitespace=0\ncache=1\ntag_id=\nclass_sfx=\nmoduleclass_sfx= menuleft\nmaxdepth=10\nmenu_images=0\nmenu_images_align=0\nmenu_images_link=0\nexpand_menu=0\nactivate_parent=0\nfull_active_id=0\nindent_image=0\nindent_image1=\nindent_image2=\nindent_image3=\nindent_image4=\nindent_image5=\nindent_image6=\nspacer=\nend_spacer=\n\n', 0, 0, ''),
(29, 'Breadcrumb', '', 0, 'breadcrumb', 0, '0000-00-00 00:00:00', 1, 'mod_breadcrumbs', 0, 0, 0, 'showHome=1\nhomeText=Home\nshowLast=1\nseparator=\nmoduleclass_sfx=\ncache=0\n\n', 0, 0, ''),
(30, 'Left', 'flourflourflourflourflourflourflourflour flour flour flourflourvflourflour flour flour flour flour flour flour flour flour flour flour flour flour flour', 0, 'left', 0, '0000-00-00 00:00:00', 1, 'mod_custom', 0, 0, 1, 'moduleclass_sfx=\n\n', 0, 0, '');

DROP TABLE IF EXISTS `jos_modules_menu`;
CREATE TABLE `jos_modules_menu` (
  `moduleid` int(11) NOT NULL DEFAULT '0',
  `menuid` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`moduleid`,`menuid`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `jos_modules_menu` VALUES
(1, 0),
(16, 0),
(17, 0),
(18, 0),
(19, 1),
(20, 0),
(21, 0),
(22, 0),
(23, 1),
(24, 0),
(27, 0),
(29, 2),
(29, 3),
(29, 4),
(29, 5),
(29, 6),
(29, 7),
(30, 2),
(30, 3),
(31, 2),
(31, 3),
(31, 4),
(31, 5),
(31, 6),
(31, 7),
(32, 0);

DROP TABLE IF EXISTS `jos_newsfeeds`;
CREATE TABLE `jos_newsfeeds` (
  `catid` int(11) NOT NULL DEFAULT '0',
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `alias` varchar(255) NOT NULL DEFAULT '',
  `link` text NOT NULL,
  `filename` varchar(200) DEFAULT NULL,
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `numarticles` int(11) unsigned NOT NULL DEFAULT '1',
  `cache_time` int(11) unsigned NOT NULL DEFAULT '3600',
  `checked_out` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `rtl` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `published` (`published`),
  KEY `catid` (`catid`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `jos_plugins`;
CREATE TABLE `jos_plugins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL DEFAULT '',
  `element` varchar(100) NOT NULL DEFAULT '',
  `folder` varchar(100) NOT NULL DEFAULT '',
  `access` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `published` tinyint(3) NOT NULL DEFAULT '0',
  `iscore` tinyint(3) NOT NULL DEFAULT '0',
  `client_id` tinyint(3) NOT NULL DEFAULT '0',
  `checked_out` int(11) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `params` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_folder` (`published`,`client_id`,`access`,`folder`)
) ENGINE=MyISAM AUTO_INCREMENT=50 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `jos_plugins` VALUES
(1, 'Authentication - Joomla', 'joomla', 'authentication', 0, 1, 1, 1, 0, 0, '0000-00-00 00:00:00', ''),
(2, 'Authentication - LDAP', 'ldap', 'authentication', 0, 2, 0, 1, 0, 0, '0000-00-00 00:00:00', 'host=\nport=389\nuse_ldapV3=0\nnegotiate_tls=0\nno_referrals=0\nauth_method=bind\nbase_dn=\nsearch_string=\nusers_dn=\nusername=\npassword=\nldap_fullname=fullName\nldap_email=mail\nldap_uid=uid\n\n'),
(3, 'Authentication - GMail', 'gmail', 'authentication', 0, 4, 0, 0, 0, 0, '0000-00-00 00:00:00', ''),
(4, 'Authentication - OpenID', 'openid', 'authentication', 0, 3, 0, 0, 0, 0, '0000-00-00 00:00:00', ''),
(5, 'User - Joomla!', 'joomla', 'user', 0, 0, 1, 0, 0, 0, '0000-00-00 00:00:00', 'autoregister=1\n\n'),
(6, 'Search - Content', 'content', 'search', 0, 1, 1, 1, 0, 0, '0000-00-00 00:00:00', 'search_limit=50\nsearch_content=1\nsearch_uncategorised=1\nsearch_archived=1\n\n'),
(7, 'Search - Contacts', 'contacts', 'search', 0, 3, 1, 1, 0, 0, '0000-00-00 00:00:00', 'search_limit=50\n\n'),
(8, 'Search - Categories', 'categories', 'search', 0, 4, 1, 0, 0, 0, '0000-00-00 00:00:00', 'search_limit=50\n\n'),
(9, 'Search - Sections', 'sections', 'search', 0, 5, 1, 0, 0, 0, '0000-00-00 00:00:00', 'search_limit=50\n\n'),
(10, 'Search - Newsfeeds', 'newsfeeds', 'search', 0, 6, 1, 0, 0, 0, '0000-00-00 00:00:00', 'search_limit=50\n\n'),
(11, 'Search - Weblinks', 'weblinks', 'search', 0, 2, 1, 1, 0, 0, '0000-00-00 00:00:00', 'search_limit=50\n\n'),
(12, 'Content - Pagebreak', 'pagebreak', 'content', 0, 10000, 1, 1, 0, 0, '0000-00-00 00:00:00', 'enabled=1\ntitle=1\nmultipage_toc=1\nshowall=1\n\n'),
(13, 'Content - Rating', 'vote', 'content', 0, 4, 1, 1, 0, 0, '0000-00-00 00:00:00', ''),
(14, 'Content - Email Cloaking', 'emailcloak', 'content', 0, 5, 1, 0, 0, 0, '0000-00-00 00:00:00', 'mode=1\n\n'),
(15, 'Content - Code Hightlighter (GeSHi)', 'geshi', 'content', 0, 5, 0, 0, 0, 0, '0000-00-00 00:00:00', ''),
(16, 'Content - Load Module', 'loadmodule', 'content', 0, 6, 1, 0, 0, 0, '0000-00-00 00:00:00', 'enabled=1\nstyle=0\n\n'),
(17, 'Content - Page Navigation', 'pagenavigation', 'content', 0, 2, 1, 1, 0, 0, '0000-00-00 00:00:00', 'position=1\n\n'),
(18, 'Editor - No Editor', 'none', 'editors', 0, 0, 1, 1, 0, 0, '0000-00-00 00:00:00', ''),
(19, 'Editor - TinyMCE', 'tinymce', 'editors', 0, 0, 1, 1, 0, 0, '0000-00-00 00:00:00', 'mode=advanced\nskin=0\ncompressed=0\ncleanup_startup=0\ncleanup_save=2\nentity_encoding=raw\nlang_mode=0\nlang_code=en\ntext_direction=ltr\ncontent_css=1\ncontent_css_custom=\nrelative_urls=1\nnewlines=0\ninvalid_elements=applet\nextended_elements=\ntoolbar=top\ntoolbar_align=left\nhtml_height=550\nhtml_width=750\nelement_path=1\nfonts=1\npaste=1\nsearchreplace=1\ninsertdate=1\nformat_date=%Y-%m-%d\ninserttime=1\nformat_time=%H:%M:%S\ncolors=1\ntable=1\nsmilies=1\nmedia=1\nhr=1\ndirectionality=1\nfullscreen=1\nstyle=1\nlayer=1\nxhtmlxtras=1\nvisualchars=1\nnonbreaking=1\ntemplate=0\nadvimage=1\nadvlink=1\nautosave=1\ncontextmenu=1\ninlinepopups=1\nsafari=1\ncustom_plugin=\ncustom_button=\n\n'),
(20, 'Editor - XStandard Lite 2.0', 'xstandard', 'editors', 0, 0, 0, 1, 0, 0, '0000-00-00 00:00:00', ''),
(21, 'Editor Button - Image', 'image', 'editors-xtd', 0, 0, 1, 0, 0, 0, '0000-00-00 00:00:00', ''),
(22, 'Editor Button - Pagebreak', 'pagebreak', 'editors-xtd', 0, 0, 1, 0, 0, 0, '0000-00-00 00:00:00', ''),
(23, 'Editor Button - Readmore', 'readmore', 'editors-xtd', 0, 0, 1, 0, 0, 0, '0000-00-00 00:00:00', ''),
(24, 'XML-RPC - Joomla', 'joomla', 'xmlrpc', 0, 7, 0, 1, 0, 0, '0000-00-00 00:00:00', ''),
(25, 'XML-RPC - Blogger API', 'blogger', 'xmlrpc', 0, 7, 0, 1, 0, 0, '0000-00-00 00:00:00', 'catid=1\nsectionid=0\n\n'),
(27, 'System - SEF', 'sef', 'system', 0, 1, 1, 0, 0, 0, '0000-00-00 00:00:00', ''),
(28, 'System - Debug', 'debug', 'system', 0, 2, 1, 0, 0, 0, '0000-00-00 00:00:00', 'queries=1\nmemory=1\nlangauge=1\n\n'),
(29, 'System - Legacy', 'legacy', 'system', 0, 3, 0, 1, 0, 0, '0000-00-00 00:00:00', 'route=0\n\n'),
(30, 'System - Cache', 'cache', 'system', 0, 4, 0, 1, 0, 0, '0000-00-00 00:00:00', 'browsercache=0\ncachetime=15\n\n'),
(31, 'System - Log', 'log', 'system', 0, 5, 0, 1, 0, 0, '0000-00-00 00:00:00', ''),
(32, 'System - Remember Me', 'remember', 'system', 0, 6, 1, 1, 0, 0, '0000-00-00 00:00:00', ''),
(33, 'System - Backlink', 'backlink', 'system', 0, 7, 0, 1, 0, 0, '0000-00-00 00:00:00', ''),
(34, 'System - Mootools Upgrade', 'mtupgrade', 'system', 0, 8, 0, 1, 0, 0, '0000-00-00 00:00:00', ''),
(35, 'Editor - JCE 1.5.7.4', 'jce', 'editors', 0, 0, 1, 0, 0, 0, '0000-00-00 00:00:00', ''),
(36, 'Content - RSForm! Pro', 'rsform', 'content', 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00', ''),
(37, 'Content - Joomla Extra News Plugin', 'extranews', 'content', 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00', 'enabled=1\nsectionid_list=-\ncatid_list=-\nid_list=-\nqueryby=c_dsc\nrelateditemscount=5\nneweritemscount=5\noderitemscount=5\nshowdate=1\nshowdateformat=d/m/Y H:i\nlinkedtitleformat=%1$s - %2$s\ntextbefore=<hr color=\"maroon\" width=\"85%\"></hr>\ntextafter=<hr color=\"maroon\" width=\"85%\"></hr>\nmarginleft=5%\nmarginright=5%\nenable_tooltip=yes\nload_mootools=no\nscriptIE6_tooltip=2\nt_char_count_desc=150\ntooltip_desc_images=yes\nimg_width=100\nimg_height=100\ntooltip_width=270\ntooltip_height=120\ntooltip_bgcolor=#000000\ntooltip_capcolor=#ffffff\ntooltip_fgcolor=#ffffff\ntooltip_textcolor=#000000\ntooltip_border=1\n'),
(38, 'System - Vinaora Visitors Counter', 'vvisit_counter', 'system', 0, -100, 1, 0, 0, 0, '0000-00-00 00:00:00', ''),
(39, '2J Tabs Plugin', '2j_tabs', 'system', 0, 0, 1, 0, 0, 0, '0000-00-00 00:00:00', 'all_width=\nall_height=\npend_all_left=\npend_all_right=\npend_all_top=\npend_all_bottom=\npage_bar=0\nalign_tab=0\nch_tabs=0\nenable_hover=0\nfont_tab=\nfont_size_tab=\npending_need=0\npend_li_left=\npend_li_right=\npend_ul_left=\npend_ul_right=\nbg_color=\nstyle=1\nshow_border=0\ncolor_border=#000000\neffect=0\nduration=200\ntimer=0\ntimer_time=3000\n\n'),
(40, 'System - Jfdatabase', 'jfdatabase', 'system', 0, -100, 1, 0, 0, 0, '0000-00-00 00:00:00', ''),
(41, 'System - Jfrouter', 'jfrouter', 'system', 0, -101, 1, 0, 0, 0, '0000-00-00 00:00:00', ''),
(42, 'Content - Jfalternative', 'jfalternative', 'content', 0, 0, 1, 0, 0, 0, '0000-00-00 00:00:00', ''),
(43, 'Search - Jfcategories', 'jfcategories', 'search', 0, 0, 1, 0, 0, 0, '0000-00-00 00:00:00', ''),
(44, 'Search - Jfcontacts', 'jfcontacts', 'search', 0, 0, 1, 0, 0, 0, '0000-00-00 00:00:00', ''),
(45, 'Search - Jfcontent', 'jfcontent', 'search', 0, 0, 1, 0, 0, 0, '0000-00-00 00:00:00', ''),
(46, 'Search - Jfnewsfeeds', 'jfnewsfeeds', 'search', 0, 0, 1, 0, 0, 0, '0000-00-00 00:00:00', ''),
(47, 'Search - Jfsections', 'jfsections', 'search', 0, 0, 1, 0, 0, 0, '0000-00-00 00:00:00', ''),
(48, 'Search - Jfweblinks', 'jfweblinks', 'search', 0, 0, 1, 0, 0, 0, '0000-00-00 00:00:00', ''),
(49, 'Joomfish - Missing_translation', 'missing_translation', 'joomfish', 0, 0, 1, 0, 0, 0, '0000-00-00 00:00:00', '');

DROP TABLE IF EXISTS `jos_poll_data`;
CREATE TABLE `jos_poll_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pollid` int(11) NOT NULL DEFAULT '0',
  `text` text NOT NULL,
  `hits` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `pollid` (`pollid`,`text`(1))
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `jos_poll_date`;
CREATE TABLE `jos_poll_date` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `vote_id` int(11) NOT NULL DEFAULT '0',
  `poll_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `poll_id` (`poll_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `jos_poll_menu`;
CREATE TABLE `jos_poll_menu` (
  `pollid` int(11) NOT NULL DEFAULT '0',
  `menuid` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`pollid`,`menuid`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `jos_polls`;
CREATE TABLE `jos_polls` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `voters` int(9) NOT NULL DEFAULT '0',
  `checked_out` int(11) NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `access` int(11) NOT NULL DEFAULT '0',
  `lag` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `jos_sections`;
CREATE TABLE `jos_sections` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL DEFAULT '',
  `name` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `image` text NOT NULL,
  `scope` varchar(50) NOT NULL DEFAULT '',
  `image_position` varchar(30) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out` int(11) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `access` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `count` int(11) NOT NULL DEFAULT '0',
  `params` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_scope` (`scope`)
) ENGINE=MyISAM AUTO_INCREMENT=3 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `jos_sections` VALUES
(1, 'Mekong', '', 'mekong', '', 'content', 'left', '', 1, 0, '0000-00-00 00:00:00', 1, 0, 2, ''),
(2, 'Sản phẩm', '', 'sn-phm', '', 'content', 'left', '', 1, 0, '0000-00-00 00:00:00', 2, 0, 0, '');

DROP TABLE IF EXISTS `jos_session`;
CREATE TABLE `jos_session` (
  `username` varchar(150) DEFAULT '',
  `time` varchar(14) DEFAULT '',
  `session_id` varchar(200) NOT NULL DEFAULT '0',
  `guest` tinyint(4) DEFAULT '1',
  `userid` int(11) DEFAULT '0',
  `usertype` varchar(50) DEFAULT '',
  `gid` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `client_id` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `data` longtext,
  PRIMARY KEY (`session_id`(64)),
  KEY `whosonline` (`guest`,`usertype`),
  KEY `userid` (`userid`),
  KEY `time` (`time`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `jos_session` VALUES
('', '1316735328', 'r0hgglc4v1nctntip2kfpnf5g4', 1, 0, '', 0, 0, '__default|a:7:{s:15:\"session.counter\";i:5;s:19:\"session.timer.start\";i:1316735300;s:18:\"session.timer.last\";i:1316735318;s:17:\"session.timer.now\";i:1316735328;s:22:\"session.client.browser\";s:67:\"Mozilla/5.0 (Windows NT 6.1; rv:6.0.2) Gecko/20100101 Firefox/6.0.2\";s:8:\"registry\";O:9:\"JRegistry\":3:{s:17:\"_defaultNameSpace\";s:7:\"session\";s:9:\"_registry\";a:2:{s:7:\"session\";a:1:{s:4:\"data\";O:8:\"stdClass\":0:{}}s:11:\"application\";a:1:{s:4:\"data\";O:8:\"stdClass\":1:{s:4:\"lang\";s:5:\"en-GB\";}}}s:7:\"_errors\";a:0:{}}s:4:\"user\";O:5:\"JUser\":19:{s:2:\"id\";i:0;s:4:\"name\";N;s:8:\"username\";N;s:5:\"email\";N;s:8:\"password\";N;s:14:\"password_clear\";s:0:\"\";s:8:\"usertype\";N;s:5:\"block\";N;s:9:\"sendEmail\";i:0;s:3:\"gid\";i:0;s:12:\"registerDate\";N;s:13:\"lastvisitDate\";N;s:10:\"activation\";N;s:6:\"params\";N;s:3:\"aid\";i:0;s:5:\"guest\";i:1;s:7:\"_params\";O:10:\"JParameter\":7:{s:4:\"_raw\";s:0:\"\";s:4:\"_xml\";N;s:9:\"_elements\";a:0:{}s:12:\"_elementPath\";a:1:{i:0;s:58:\"D:\\wamp\\www\\mekong\\libraries\\joomla\\html\\parameter\\element\";}s:17:\"_defaultNameSpace\";s:8:\"_default\";s:9:\"_registry\";a:1:{s:8:\"_default\";a:1:{s:4:\"data\";O:8:\"stdClass\":0:{}}}s:7:\"_errors\";a:0:{}}s:9:\"_errorMsg\";N;s:7:\"_errors\";a:0:{}}}'),
('', '1316735227', 'hakp8p0fe47kb19pc9c59gbte2', 1, 0, '', 0, 1, '__default|a:8:{s:15:\"session.counter\";i:1;s:19:\"session.timer.start\";i:1316735224;s:18:\"session.timer.last\";i:1316735224;s:17:\"session.timer.now\";i:1316735224;s:22:\"session.client.browser\";s:67:\"Mozilla/5.0 (Windows NT 6.1; rv:6.0.2) Gecko/20100101 Firefox/6.0.2\";s:8:\"registry\";O:9:\"JRegistry\":3:{s:17:\"_defaultNameSpace\";s:7:\"session\";s:9:\"_registry\";a:1:{s:7:\"session\";a:1:{s:4:\"data\";O:8:\"stdClass\":0:{}}}s:7:\"_errors\";a:0:{}}s:4:\"user\";O:5:\"JUser\":19:{s:2:\"id\";i:0;s:4:\"name\";N;s:8:\"username\";N;s:5:\"email\";N;s:8:\"password\";N;s:14:\"password_clear\";s:0:\"\";s:8:\"usertype\";N;s:5:\"block\";N;s:9:\"sendEmail\";i:0;s:3:\"gid\";i:0;s:12:\"registerDate\";N;s:13:\"lastvisitDate\";N;s:10:\"activation\";N;s:6:\"params\";N;s:3:\"aid\";i:0;s:5:\"guest\";i:1;s:7:\"_params\";O:10:\"JParameter\":7:{s:4:\"_raw\";s:0:\"\";s:4:\"_xml\";N;s:9:\"_elements\";a:0:{}s:12:\"_elementPath\";a:1:{i:0;s:58:\"D:\\wamp\\www\\mekong\\libraries\\joomla\\html\\parameter\\element\";}s:17:\"_defaultNameSpace\";s:8:\"_default\";s:9:\"_registry\";a:1:{s:8:\"_default\";a:1:{s:4:\"data\";O:8:\"stdClass\":0:{}}}s:7:\"_errors\";a:0:{}}s:9:\"_errorMsg\";N;s:7:\"_errors\";a:0:{}}s:13:\"session.token\";s:32:\"276a3a5cf0e09b7e6e2326bf4e4c53e1\";}'),
('admin', '1316735281', 'edgvgpcsahpcjc74ps2eqcf165', 0, 62, 'Super Administrator', 25, 1, '__default|a:8:{s:15:\"session.counter\";i:11;s:19:\"session.timer.start\";i:1316735224;s:18:\"session.timer.last\";i:1316735278;s:17:\"session.timer.now\";i:1316735281;s:22:\"session.client.browser\";s:67:\"Mozilla/5.0 (Windows NT 6.1; rv:6.0.2) Gecko/20100101 Firefox/6.0.2\";s:8:\"registry\";O:9:\"JRegistry\":3:{s:17:\"_defaultNameSpace\";s:7:\"session\";s:9:\"_registry\";a:5:{s:7:\"session\";a:1:{s:4:\"data\";O:8:\"stdClass\":0:{}}s:11:\"application\";a:1:{s:4:\"data\";O:8:\"stdClass\":1:{s:4:\"lang\";s:0:\"\";}}s:10:\"com_cpanel\";a:1:{s:4:\"data\";O:8:\"stdClass\":1:{s:9:\"mtupgrade\";O:8:\"stdClass\":1:{s:7:\"checked\";b:1;}}}s:11:\"com_plugins\";a:1:{s:4:\"data\";O:8:\"stdClass\":2:{s:4:\"site\";O:8:\"stdClass\":5:{s:12:\"filter_order\";s:4:\"p.id\";s:16:\"filter_order_Dir\";s:4:\"desc\";s:12:\"filter_state\";s:0:\"\";s:11:\"filter_type\";s:1:\"1\";s:6:\"search\";s:0:\"\";}s:10:\"limitstart\";i:0;}}s:6:\"global\";a:1:{s:4:\"data\";O:8:\"stdClass\":1:{s:4:\"list\";O:8:\"stdClass\":1:{s:5:\"limit\";i:20;}}}}s:7:\"_errors\";a:0:{}}s:4:\"user\";O:5:\"JUser\":19:{s:2:\"id\";s:2:\"62\";s:4:\"name\";s:13:\"Administrator\";s:8:\"username\";s:5:\"admin\";s:5:\"email\";s:22:\"htkieuphuong@gmail.com\";s:8:\"password\";s:65:\"352190e329693afc5832d28226d72dca:YxawdtNuGxbslSRoJAeUVPOuLcATYkRF\";s:14:\"password_clear\";s:0:\"\";s:8:\"usertype\";s:19:\"Super Administrator\";s:5:\"block\";s:1:\"0\";s:9:\"sendEmail\";s:1:\"1\";s:3:\"gid\";s:2:\"25\";s:12:\"registerDate\";s:19:\"2010-10-27 16:01:05\";s:13:\"lastvisitDate\";s:19:\"2011-09-22 06:58:15\";s:10:\"activation\";s:0:\"\";s:6:\"params\";s:0:\"\";s:3:\"aid\";i:2;s:5:\"guest\";i:0;s:7:\"_params\";O:10:\"JParameter\":7:{s:4:\"_raw\";s:0:\"\";s:4:\"_xml\";N;s:9:\"_elements\";a:0:{}s:12:\"_elementPath\";a:1:{i:0;s:58:\"D:\\wamp\\www\\mekong\\libraries\\joomla\\html\\parameter\\element\";}s:17:\"_defaultNameSpace\";s:8:\"_default\";s:9:\"_registry\";a:1:{s:8:\"_default\";a:1:{s:4:\"data\";O:8:\"stdClass\":0:{}}}s:7:\"_errors\";a:0:{}}s:9:\"_errorMsg\";N;s:7:\"_errors\";a:0:{}}s:13:\"session.token\";s:32:\"276a3a5cf0e09b7e6e2326bf4e4c53e1\";}');

DROP TABLE IF EXISTS `jos_stats_agents`;
CREATE TABLE `jos_stats_agents` (
  `agent` varchar(255) NOT NULL DEFAULT '',
  `type` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hits` int(11) unsigned NOT NULL DEFAULT '1'
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `jos_templates_menu`;
CREATE TABLE `jos_templates_menu` (
  `template` varchar(255) NOT NULL DEFAULT '',
  `menuid` int(11) NOT NULL DEFAULT '0',
  `client_id` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`menuid`,`client_id`,`template`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `jos_templates_menu` VALUES
('vietprotocol', 0, 0),
('khepri', 0, 1);

DROP TABLE IF EXISTS `jos_users`;
CREATE TABLE `jos_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `username` varchar(150) NOT NULL DEFAULT '',
  `email` varchar(100) NOT NULL DEFAULT '',
  `password` varchar(100) NOT NULL DEFAULT '',
  `usertype` varchar(25) NOT NULL DEFAULT '',
  `block` tinyint(4) NOT NULL DEFAULT '0',
  `sendEmail` tinyint(4) DEFAULT '0',
  `gid` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `registerDate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `lastvisitDate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `activation` varchar(100) NOT NULL DEFAULT '',
  `params` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `usertype` (`usertype`),
  KEY `idx_name` (`name`),
  KEY `gid_block` (`gid`,`block`),
  KEY `username` (`username`),
  KEY `email` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=63 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `jos_users` VALUES
(62, 'Administrator', 'admin', 'htkieuphuong@gmail.com', '352190e329693afc5832d28226d72dca:YxawdtNuGxbslSRoJAeUVPOuLcATYkRF', 'Super Administrator', 0, 1, 25, '2010-10-27 16:01:05', '2011-09-22 23:47:07', '', '');

DROP TABLE IF EXISTS `jos_vvcounter_logs`;
CREATE TABLE `jos_vvcounter_logs` (
  `time` int(10) unsigned NOT NULL,
  `visits` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `guests` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `members` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `bots` mediumint(8) unsigned NOT NULL DEFAULT '0',
  UNIQUE KEY `time` (`time`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `jos_vvcounter_logs` VALUES
(1316661389, 2, 1, 1, 0),
(1316662540, 0, 0, 0, 0),
(1316663980, 0, 0, 0, 0),
(1316664000, 0, 0, 0, 0),
(1316665877, 0, 0, 0, 0),
(1316667600, 0, 0, 0, 0),
(1316669574, 0, 0, 0, 0),
(1316670927, 0, 0, 0, 0),
(1316671200, 0, 0, 0, 0),
(1316674692, 1, 1, 0, 0),
(1316674800, 0, 0, 0, 0),
(1316675706, 1, 1, 0, 0),
(1316676636, 0, 0, 0, 0),
(1316677733, 0, 0, 0, 0),
(1316678400, 0, 0, 0, 0),
(1316679380, 0, 0, 0, 0),
(1316680288, 0, 0, 0, 0),
(1316681205, 0, 0, 0, 0),
(1316682000, 0, 0, 0, 0),
(1316682910, 0, 0, 0, 0),
(1316684167, 0, 0, 0, 0),
(1316685283, 0, 0, 0, 0),
(1316685600, 0, 0, 0, 0),
(1316686503, 0, 0, 0, 0),
(1316687641, 0, 0, 0, 0),
(1316696400, 0, 0, 0, 0),
(1316699633, 1, 1, 0, 0),
(1316700000, 0, 0, 0, 0),
(1316714400, 0, 0, 0, 0),
(1316715698, 1, 1, 0, 0),
(1316718000, 0, 0, 0, 0),
(1316721450, 1, 1, 0, 0),
(1316721600, 0, 0, 0, 0),
(1316724826, 1, 1, 0, 0),
(1316725200, 0, 0, 0, 0),
(1316727531, 1, 1, 0, 0),
(1316732400, 0, 0, 0, 0),
(1316735224, 1, 1, 0, 0);

DROP TABLE IF EXISTS `jos_weblinks`;
CREATE TABLE `jos_weblinks` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` int(11) NOT NULL DEFAULT '0',
  `sid` int(11) NOT NULL DEFAULT '0',
  `title` varchar(250) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `url` varchar(250) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `hits` int(11) NOT NULL DEFAULT '0',
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out` int(11) NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `archived` tinyint(1) NOT NULL DEFAULT '0',
  `approved` tinyint(1) NOT NULL DEFAULT '1',
  `params` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`,`published`,`archived`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

